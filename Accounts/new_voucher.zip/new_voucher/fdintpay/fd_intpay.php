<?php
require('../../configuration.php');

echo "fd interest payable";
		$fd_interest_amount=$_REQUEST['amount'];
		$cheque_no=$_REQUEST['cheque_no'];
		?>
		
<table class="table table-bordered table-striped" border="1">
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td>Interest paid on FD</td>
			<td align="right"><?php echo $fd_interest_amount;?><input type="hidden" name="fd_interest_amount" id="fd_interest_amount" value="<?php echo $fd_interest_amount;?>" /></td>
			<td></td>
		</tr>
		
		<tr>
			<td>Cheque No: &nbsp; <?php echo $cheque_no;?></td>
			<td align="right"><?php echo $fd_interest_amount;?></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
</table>
		