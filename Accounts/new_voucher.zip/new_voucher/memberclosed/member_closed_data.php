<?php
require('../../configuration.php');
require('../../user.php');
require("../../phpFunction.php");
	$member_no=$_REQUEST['member_no'];
	$voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
	$ledger_code1=$_REQUEST['ledger_code'];
	$bank_code=$_REQUEST['bank_code'];
	$vou_date=$_REQUEST['vou_entry_date'];
	$vou_date=date('Y-m-d',strtotime($vou_date));
			
	//changeHeadsASL.php?
	//voucher_purpose_code=PUR-002&member_no=3825&branch_code=1749&
	//date=08-06-2018&cheque_no=74123&asl_amount=&ledger_code=&bank_code=BANK-002&vou_entry_date=08-06-2018	

			
	//changeHeadsASL.php?
	//voucher_purpose_code=PUR-002&member_no=3825&branch_code=1749&
	//date=08-06-2018&cheque_no=74123&asl_amount=&ledger_code=&bank_code=BANK-002&vou_entry_date=08-06-2018	

	$date=$_REQUEST['date'];
	$cheque_no=$_REQUEST['cheque_no'];
				
		$member_balance_sql="SELECT share_capital,srf_balance,thrift_balance,
		surety_interest,surety_reg_balance,surety_balance,surety_od_balance,surety_od_interest,
		festival_interest,festival_reg_balance,festival_balance,festival_od_balance,festival_od_interest,
		flood_balance FROM member_balance WHERE member_no='$member_no'";
		
		$member_balance_row=mysql_query($member_balance_sql);
		$member_balance_res=mysql_fetch_array($member_balance_row);
		
		$share_capital=$member_balance_res['share_capital'];
		$srf_balance=$member_balance_res['srf_balance'];
		$thrift_balance=$member_balance_res['thrift_balance'];
		
		$surety_balance=$member_balance_res['surety_balance'];
		$surety_interest=$member_balance_res['surety_interest'];
		//$surety_interest=0;
		$surety_reg_balance=$member_balance_res['surety_reg_balance'];
		$surety_od_balance=$member_balance_res['surety_od_balance'];
		$surety_od_interest_balance=$member_balance_res['surety_od_interest'];
		
		$festival_balance=$member_balance_res['festival_balance'];
		$festival_interest=$member_balance_res['festival_interest'];
		$festival_reg_balance=$member_balance_res['festival_reg_balance'];
		$festival_od_balance=$member_balance_res['festival_od_balance'];
		$festival_od_interest_balance=$member_balance_res['festival_od_interest'];
		
		$flood_balance=$member_balance_res['flood_balance'];
		
		$loan_sql="SELECT interest_rate,od_interest_rate FROM loan_type";
					
		$loan_row=mysql_query($loan_sql);
		$i=0;
		while($loan_res=mysql_fetch_array($loan_row))
		{
			 $reg_interest[$i]=$loan_res[0];
			 $od_interest[$i]=$loan_res[1];
			 $i++;
		}
		
?>

<table class="table table-bordered table-striped" border="1">
<tbody>
	<tr>
		<td>Surety Loan Balance</td>
		<td><?php echo $surety_balance;?></td>
		<td></td>
		<td>Share Capital</td>
		<td><?php echo $share_capital;?></td>
		<td></td>
	</tr>
	<tr>
		<td>Surety Loan Interest(Reg+od)</td>
		<td>
		<?php 
				
		$int_relaxation=mysql_query("select * from surety_loan_relaxation where member_no='$member_no'");
		$int_relax=mysql_num_rows($int_relaxation);
		
		if($int_relax>0)
		{
			$interest_date=date("Y-m-d",strtotime($date));
			$interest_date1=date("d",strtotime($date));
			$lastDay=31;
			$surety_reg_interest=0;
			$surety_interest=0;
			$surety_od_interest=0;
		}
		else
		{		
				$surety_reg_interest=0;
				$surety_od_interest=($surety_od_balance*$od_interest[0]/100)*1/12;
				
				$interest_date=date("Y-m-d",strtotime($date));
				$interest_date1=date("d",strtotime($date));
				
				$m=date("m",strtotime($date));
				$y=date("Y",strtotime($date));
				
				if($m=='01' || $m=='03' || $m=='05' || $m=='07' || $m=='08' || $m=='10' || $m=='12')
				{
					$lastDay=31;
				}
				else if($m=='04' || $m=='06' || $m=='09' || $m=='11')
				{
					$lastDay=30;
				}
				else if($m=='02')
				{
							if( (0 == $y % 4) and (0 != $y % 100) or (0 == $y % 400) )
							{
								$lastDay=29;
							}
							else
							{
								$lastDay=28;
							}
				}
				
				
				if($interest_date1<=15)
				{
					$surety_reg_interest=($surety_reg_balance*$reg_interest[0]/100)*1/12;
					$surety_reg_interest=$surety_reg_interest/2;
					
					$surety_od_interest=$surety_od_interest/2;
					
					$badate=$y.'-'.$m.'-'.$interest_date1;
					$bsdate=$y.'-'.$m.'-'.'01';
					$bul_sql="SELECT SUM(surety_interest) as surety_reg_interest,
								SUM(surety_od_interest) as surety_od_interest
								FROM bulk_collection WHERE member_no='$member_no'
								AND
									date(date)
									BETWEEN '$bsdate'
									AND
										'$badate'
								";
								
					$bul_res=mysql_fetch_array(mysql_query($bul_sql));
					
					$paidsurInt=$bul_res['surety_reg_interest'];
					$paidSurODInt=$bul_res['surety_od_interest'];
					
					
					if($surety_reg_interest<$paidsurInt)
					{
					
					$surety_reg_interest='';
					}
					else
					{
					$surety_reg_interest=$surety_reg_interest-$paidsurInt;
					}
					if($surety_od_interest<$paidSurODInt)
					{
					}
					else
					{
					$surety_od_interest=$surety_od_interest-$paidSurODInt;
					}
					
					
				}
				
				if($interest_date1=="01" || $interest_date1==$lastDay)
				{
			
					$surety_reg_interest=0;
					$surety_od_interest=0;
				}
				
				
				$surety_interest=round($surety_interest+$surety_reg_interest+$surety_od_interest+$surety_od_interest_balance);					
				
				
				echo number_format((float)$surety_interest,2,'.','');
		}
			?>
			<input type="hidden" name="surety_interest" id="surety_interest" 
			value="<?php echo $surety_interest;?>" />
			<input type="hidden" name="surety_reg_interest_rate" id="surety_reg_interest_rate" value="<?php echo $reg_interest[0];?>" />
			<input type="hidden" name="surety_od_interest_rate" id="surety_od_interest_rate" value="<?php echo $od_interest[0];?>" />
			<input type="hidden" name="surety_reg_interest_amount" id="surety_reg_interest_amount" value="<?php echo $surety_reg_interest;?>" />
			<input type="hidden" name="surety_od_interest_amount" id="surety_od_interest_amount" value="<?php echo $surety_od_interest;?>" />
			</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td>Thrift Deposit</td>
			<td><?php echo $thrift_balance;?></td>
			<td></td>
		</tr>
		<tr>
			<td>Festival Loan </td>
			<td><?php echo $festival_balance;?></td>
			<td></td>
			<td>S.R.F</td>
			<td><?php echo $srf_balance;?></td>
			<td></td>
		</tr>
			<tr>
			<td>Festival Loan Interest(Reg+od)</td>
			<td><?php 
						
					$festival_reg_interest=($festival_reg_balance*$reg_interest[1]/100)*1/12;
				
					$festival_od_interest=($festival_od_balance*$od_interest[1]/100)*1/12;
					

					if($interest_date1<=15)
					{
						$festival_reg_interest=$festival_reg_interest/2;
						$festival_od_interest=$festival_od_interest/2;
					}
					if($interest_date1==1 || $interest_date1==$lastDay)
					{
						$festival_reg_interest=0;
						$festival_od_interest=0;
					}
					$festival_interest=round($festival_reg_interest+$festival_od_interest+$festival_od_interest_balance);
					echo number_format((float)$festival_interest,2,'.','');
				?>
				<input type="hidden" name="festival_interest" id="festival_interest" value="<?php echo $festival_interest;?>" />
				<input type="hidden" name="festival_reg_interest_rate" id="festival_reg_interest_rate" value="<?php echo $reg_interest[1];?>" />
				<input type="hidden" name="festival_od_interest_rate" id="festival_od_interest_rate" value="<?php echo $od_interest[1];?>" />
				<input type="hidden" name="festival_reg_interest_amount" id="festival_reg_interest_amount" value="<?php echo $festival_reg_interest;?>" />
				<input type="hidden" name="festival_od_interest_amount" id="festival_od_interest_amount" value="<?php echo $festival_od_interest;?>" />
				</td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td>Interest on Thrift</td>
			<td><?php $intMas_sql="SELECT percentage FROM interest_master WHERE name='THRIFT DEPOSIT' order by id desc LIMIT 1";
			$intMas_row=mysql_query($intMas_sql);
			$intMas_res=mysql_fetch_row($intMas_row);
			$thrift_interest_percentage=$intMas_res[0];
						
			/*$tdsInsTrn_sql="SELECT SUM(interest_amount) as paid_interest
								FROM
								tds_interest_transaction
							WHERE
							  member_no='$member_no' ";
			$tdsInsTrn_row=mysql_query($tdsInsTrn_sql);
			$tdsInsTrn_res=mysql_fetch_row($tdsInsTrn_row);*/
			$tdsIns_paid=0;
						
						
						
			$tdsIns_sql="SELECT SUM(thrift_interest) as payable_interest
							FROM	
							demand
						WHERE
							member_no='$member_no' and date<'$vou_date'";
						$tdsIns_row=mysql_query($tdsIns_sql);
						$tdsIns_res=mysql_fetch_row($tdsIns_row);
						$tdsIns_payable=$tdsIns_res[0];
						
						
						
						$year=date("Y",strtotime($date));
						$month=date("m",strtotime($date));
						
						$from_date='01'.$month.$year;
						
						$from_date=date("Y-m-d",strtotime($from_date));
						$to_date=date("Y-m-d",strtotime($date));
						
						$from_date = strtotime($from_date);
						$to_date = strtotime($to_date);
						
						$monthsDays=getMonthDays($from_date,$to_date);
						
						$splitMonthDays=explode("-",$monthsDays);
						$month=$splitMonthDays[0];
						$days=$splitMonthDays[1];
						
						$month_interest=($thrift_balance*$thrift_interest_percentage/100)*1/12;
						$month_interest=round($month_interest);
							
						
						if($days<15)
						{
							$thrfitIns1=$month_interest/2;
							$thrift_interest=round($thrfitIns1);
							$tdsIns_payable=($tdsIns_payable+$thrift_interest)-$tdsIns_paid;
						}
						else
						{
							$thrfitIns1=0;
							$thrift_interest=round($thrfitIns1);
							$tdsIns_payable=($tdsIns_payable+$thrift_interest)-$tdsIns_paid;
						}
						
						echo number_format((float)$tdsIns_payable,2,'.','');

						
					?>
					<input type="hidden" name="thrift_interest_percentage" id="thrift_interest_percentage" value="<?php echo $thrift_interest_percentage;?>" />
					<input type="hidden" name="thrift_interest_amount" id="thrift_interest_amount" value="<?php echo $tdsIns_payable;?>" />
					</td>
			<td></td>
		</tr>
		<tr>
			<td>Flood Loan </td>
			<td><?php echo $flood_balance;?></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<tr>
		<td>
		<?php 
		$intMas_sql1="SELECT percentage FROM interest_master WHERE name='SRF' order by id desc LIMIT 1";
		$intMas_row1=mysql_query($intMas_sql1);
		$intMas_res1=mysql_fetch_row($intMas_row1);
		$srf_interest=$intMas_res1[0];
		$srf_interest=0;
					
					//echo $srf_interest."% SRF";?> </td>
		<td><?php 	
		$srf_balance=$member_balance_res['srf_balance'];
		$srf_deduct=$srf_balance*$srf_interest/100 ;
		$srf_deduct=round($srf_deduct);
		$srf_deduct=0;
		?>
		<input type="hidden" name="srf_deduct_percentage" id="srf_deduct_percentage" value="<?php echo $srf_interest;?>" />
		<input type="hidden" name="srf_deduct_amount" id="srf_deduct_amount" value="<?php echo $srf_deduct;?>" />
		</td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<!--changed by laxmi-->
				<?php
						$asset=$share_capital+$srf_balance+$thrift_balance+$tdsIns_payable;
						
						$liabilities=$surety_balance+$festival_balance+$flood_balance+$srf_deduct+$surety_interest+$festival_interest;
						
						if($asset>$liabilities)
							{
								$balance=$asset-$liabilities;
								$balance=round($balance);
							}
						else
							{
								$balance=0;
							
							}
							if($asset<$liabilities)
							{
								$balance1=$liabilities-$asset;
								$balance1=round($balance1);
							}
						else
							{
								$balance1=0;
							
							}
				?>
				<input type="hidden" name="asset" id="asset" value="<?php echo $asset;?>" />
				<input type="hidden" name="liabilities" id="liabilities" value="<?php echo $liabilities;?>" />
				
		</tr>
		
		<tr>
		
			<?php //changed by laxmi
			if($cheque_no=='' && $asset>$liabilities) 
						{
							?>
							<td>
						<?php	
							echo  "Sundry Creditors";
							?></td>
							<td>
						<?php	
							echo  $balance;
							?></td>
						<?PHP 
						}
						?>
	
						<input type="hidden" name="balance" id="balance" value="<?php echo $balance;?>" />
					<td>
						</td>
						<td>
						</td>
						<td>
						</td>
						<?php if($cheque_no=='' && $asset<$liabilities) 
						{
							?>
							<td>
						<?php	
							echo  "Sundry Debtors";
							?></td>
							<td>
						<?php	
							echo  $balance1;
							?></td>
						<?PHP 
						}
						?>
						<td></td>
						
						<td>
			
			
			<!--<td><?php //echo $balance1=$liabilities-$asset;?></td> -->
			<input type="hidden" name="balance1" id="balance1" value="<?php echo $balance1;?>" /></td>
			<!--<td></td>
			<td></td> -->
		</tr>
				
		<tr>
			<td>Liabilities </td>
			<td><?php $liabilities=$liabilities+$balance;echo number_format((float)$liabilities,2,'.','');?></td>
			<td></td>
			<td>Asset</td>
			<td><?php $asset=$asset+$balance1; echo number_format((float)$asset,2,'.','');?></td>
			<td></td>
		</tr>
		
		
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
</tbody>
</table>