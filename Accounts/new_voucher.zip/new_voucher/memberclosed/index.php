<?php

require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];

$memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
require('../main_process.php');

$memberclosed=new voucher_process();


$bank_codes=$_REQUEST['bank_code'];
$amounts=$_REQUEST['asl_amount'];
$ledger_code=$_REQUEST['ledger_code'];

$memberclosed->voucher_category_code=$_REQUEST['vou_cat'];
$memberclosed->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
$memberclosed->code=$v_code;
$memberclosed->date=date("Y-m-d",strtotime($_REQUEST['curdate']));
$memberclosed->member_no=$_REQUEST['member_no'];
$memberclosed->name=$_REQUEST['name'];
$memberclosed->branch_code=$_REQUEST['branch_code'];
$memberclosed->amount=$amounts;
$memberclosed->ledger_code=$ledger_code;
$memberclosed->narration='MEMBER CLOSED - ADJ SLIP';

$memberclosed->bank_code=$bank_codes;

//$memberclosed->voucher_entry();                  	// voucher insert
	
$ledgers_code=array($ledger_code);
$ledgers_amount=array($amounts);
ledgers_type=array('debit');

//$memberclosed->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);	 //voucher_details insert
	

?>