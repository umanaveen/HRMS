<?php
	require("../../configuration.php");
	require("../../phpFunction.php");
	$member_no=$_REQUEST['member_no'];
	$voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
	$ledger_code1=$_REQUEST['ledger_code'];
	$bank_code=$_REQUEST['bank_code'];
	$vou_date=$_REQUEST['vou_entry_date'];
	$vou_date=date('Y-m-d',strtotime($vou_date));
?>
<table class="table table-bordered table-striped" border="1">
<thead>
<?PHP
if($ledger_code1!='Z001')  // its member closed
{	
	?>
<tr>
	<td colspan="3"><center>RECEIPTS</center></td>
	<td colspan="3"><center>PAYMENTS</center></td>
</tr>
<tr>
	<td>Head of Account</td>
	<td colspan="2">Amount</td>
	<td>Head of Account</td>
	<td colspan="2">Amount</td>
</tr>
<tr>
	<td></td>
	<td>Rs.</td>
	<td>P.</td>
	<td></td>
	<td>Rs.</td>
	<td>P.</td>
</tr>
<?PHP
}
else
{
	?>
<tr>
	<td colspan=6><center>RECEIPTS</center></td>
</tr>
<tr>
	
	<td colspan=4>Head of Account</td>
	<td colspan=2>Amount</td>
</tr>
<tr>
	<td colspan=4></td>
	<td>Rs.</td>
	<td>P.</td>
</tr>
<?PHP
}
?>
</thead>
<?php
$date=$_REQUEST['date'];
		$cheque_no=$_REQUEST['cheque_no'];
		$asl_amount=$_REQUEST['asl_amount'];
		$ledger_code=$_REQUEST['ledger_code'];
		$branch_code=$_REQUEST['branch_code'];
		$bank_code=$_REQUEST['bank_code'];
					
		$bank_res=mysql_fetch_array(mysql_query("SELECT name,ledger_code FROM bank where code='$bank_code'"));
		$receipt_name=$bank_res['name'];
		$receipt_code=$bank_res['ledger_code'];
		
		$bank_pay=mysql_fetch_array(mysql_query("SELECT name,code FROM bank where ledger_code='$ledger_code'"));
		$pay_code=$bank_pay['code'];
		$pay_name=$bank_pay['name'];
	
		if($ledger_code=='I001')
		{
	?>
		<tbody>
		<tr	>
		<td><?php echo $cheque_no; ?></td>
		<td><?php echo $asl_amount;?></td>
		<td></td>
		<td><?php echo "SUNDRY DEBTORS";?></td>
		<td><?php echo $asl_amount;?></td>
		<td></td>
		</tr>
		<tr>
		<td><?php echo $receipt_code.'-'.$receipt_name; ?></td>
		<td></td>
		<td></td>
		<td><?php echo $ledger_code.'-'.$pay_name;?></td>
		<td></td>
		<td></td>
		</tr>
		
	<input type="hidden" id="payable_amount" name="payable_amount" value="<?php echo $asl_amount;?>" />
	<input type="hidden" id="payableSplit[]" name="payableSplit[]" value="<?php echo $asl_amount;?>" />
	<input type="hidden" id="payableAgainst[]" name="payableAgainst[]" value="<?php echo $ledger_code;?>" />
		</tbody>
		<?php
		}
		
		//END SUNDRY DEBTORS
		else if($ledger_code=='I002')
		{
			if($member_no=='' || $member_no==null)
			{
				$scr_sql="SELECT SUM(amount) as payable_amount
						FROM
							sundry_creditors
						WHERE
							reference='$branch_code'			
						AND
							flag_id=19 ";
							
			}
			else
			{
			
			$scr_sql="SELECT SUM(amount) as payable_amount
						FROM
							sundry_creditors
						WHERE
							member_no='$member_no'
						AND reference='$branch_code'
						AND 
							flag_id=19 ";
							
			}
						//echo $scr_sql;
		$scr_row=mysql_query($scr_sql);
		$scr_res=mysql_fetch_array($scr_row);
		
		$payable_amount=$scr_res['payable_amount'];
	?>
	<tbody>
	<tr>
	<td><?php echo $cheque_no; ?></td>
	<td><?php echo $payable_amount;?></td>
	<td></td>
	<td><?php echo "SUNDRY CREDITORS";?></td>
	<td></td>
	<td></td>
	</tr>
	<tr>
		<td><?php echo $receipt_code.'-'.$receipt_name; ?></td>
		<td></td>
		<td></td>
		<td><?php echo $ledger_code.'-'.$pay_name;?></td>
		<td></td>
		<td></td>
		</tr>
	
	<input type="hidden" id="payable_amount" name="payable_amount" value="<?php echo $payable_amount;?>" />
	<?php
	$scr_sql1="SELECT against,amount
	FROM
	sundry_creditors
	WHERE
	member_no='$member_no'
	and reference='$branch_code'
	AND
	flag_id=19";

	$scr_row1=mysql_query($scr_sql1);
	while($scr_res1=mysql_fetch_array($scr_row1))
	{
	?>
	<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php echo $scr_res1['amount'];?></td>
	<td></td>
	</tr>
	<input type="hidden" id="payableSplit[]" name="payableSplit[]" value="<?php echo $scr_res1['amount'];?>" />
	<input type="hidden" id="payableAgainst[]" name="payableAgainst[]" value="<?php echo $scr_res1['against'];?>" />
	<?php
	}
	?>
	</tbody>
	<?php
	}
	else if($ledger_code=='Z001')
	{
	$bank_fetch_code=mysql_fetch_array(mysql_query("SELECT name FROM bank WHERE code='$bank_code'"));

	?>
	<tbody>
	<tr>
		<td><?php echo $cheque_no; ?></td>
		<td colspan=3><?php echo $bank_fetch_code['name'];?></td>
		<td><?php echo $asl_amount;?></td>
		<td></td>
	</tr>
	<tr>
		<td><?php echo $receipt_code.'-'.$receipt_name; ?></td>
		<td></td>
		<td></td>
		<td><?php echo $ledger_code.'-'.$pay_name;?></td>
		<td></td>
		<td></td>
		</tr>
	<input type="hidden" id="payable_amount" name="payable_amount" value="<?php echo $asl_amount;?>" />
	<?php
	}
	//----------staff loan closed voucher----
	else if($ledger_code=='G007' || $ledger_code=='G006' || $ledger_code=='G009'|| $ledger_code=='G008'|| $ledger_code=='M006')
	{
		$bank_fetch_code1=mysql_fetch_array(mysql_query("SELECT name,ledger_code FROM bank WHERE code='$bank_code'"));
		?>
	<tbody>
		<tr>
			<td><?php echo $ledger_code; ?></td>
			<td><?php echo $asl_amount;?></td>
			<td></td>
			<td><?php echo $bank_fetch_code1['ledger_code']." ".$cheque_no;?></td>
			<td><?php echo $asl_amount;?></td>
			<td></td>
		</tr>
		<tr>
		<td><?php echo $receipt_code.'-'.$receipt_name; ?></td>
		<td></td>
		<td></td>
		<td><?php echo $ledger_code.'-'.$pay_name; ?></td>
		<td></td>
		<td></td>
		</tr>
		<input type="hidden" id="payable_amount" name="payable_amount" value="<?php echo $asl_amount;?>" />
		<?php
	}//----------staff loan closed voucher----
	else
	{
		?>
	<tbody>
		<tr>
			<td><?php echo $cheque_no; ?></td>
			<td><?php echo $asl_amount;?></td>
			<td></td>
			<td><?php echo $ledger_code;?></td>
			<td><?php echo $asl_amount;?></td>
			<td></td>
		</tr>
		<tr>
		<td><?php echo $receipt_code.'-'.$receipt_name; ?></td>
		<td></td>
		<td></td>
		<td><?php echo $ledger_code.'-'.$pay_name; ?></td>
		<td></td>
		<td></td>
		</tr>
		<input type="hidden" id="payable_amount" name="payable_amount" value="<?php echo $asl_amount;?>" />
		<?php
	}
?>