<?php
require('../../configuration.php');
require('../../user.php');

$user=$_SESSION['user'];
 	
 $memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
require('../main_process.php');
	
$bank_codes=$_REQUEST['bank_code'];
$ledger_codes=$_REQUEST['ledger_code'];
$amounts=$_REQUEST['asl_amount'];
 
 $againstledger=new voucher_process();	// CALL A CLASS NAME
 
	 $againstledger->code=$v_code;
	
$againstledger->voucher_category_code=$_REQUEST['voucher_category_code'];
$againstledger->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
$againstledger->date=date('Y-m-d'strtotime($_REQUEST['curdate']));
$againstledger->member_no=$_REQUEST['member_no'];
$againstledger->name=$_REQUEST['name'];
$againstledger->branch_code=$_REQUEST['branch_code'];
$againstledger->bank_code=$bank_codes;
$againstledger->amount=$amounts;
$againstledger->cheque_no=$_REQUEST['cheque_no'];
$againstledger->cheque_date=date('Y-m-d'strtotime($_REQUEST['cheque_date']));

	$bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_codes'");
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	$staffadjustmentcollection->ledger_code=$ledger_code;
	
	$againstledger->ledger_code=$ledger_codes;
	$againstledger->narration='AGAINST LEDGERS';
    $againstledger->created_by=$user;
    $againstledger->status=1;
	
$againstledger->payable_amount=$_REQUEST['payable_amount'];  // 1 values get from against_legder_details.php

	// $againstledger->voucher_entry(); 
 
 $ledgers_code=array($ledger_codes,$ledger_code);
 $ledgers_amount=array($amounts,$amounts);
 $ledgers_type=array('credit','debit');
 
	// $againstledger->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);
  
?>