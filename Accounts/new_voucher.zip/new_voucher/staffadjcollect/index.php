<?php
require('../../configuration.php');
require('../../user.php');

$memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}

require('../main_process.php');

$bank_codes=$_REQUEST['bank_code'];
$amounts=$_REQUEST['amount'];

$staffadjustmentcollection=new voucher_process(); 

$staffadjustmentcollection->voucher_category_code=$_REQUEST['vou_cat'];
$staffadjustmentcollection->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
$staffadjustmentcollection->code=$v_code;
$staffadjustmentcollection->date=date('Y-m-d',strtotime($_REQUEST['sund_date']));
$staffadjustmentcollection->member_no=$_REQUEST['member_no'];
$staffadjustmentcollection->name=$_REQUEST['name'];
$staffadjustmentcollection->branch_code=$_REQUEST['branch_code'];
$staffadjustmentcollection->cheque_no=$_REQUEST['cheque_no'];
$staffadjustmentcollection->cheque_date=$_REQUEST['cheque_date'];
$staffadjustmentcollection->amount=$amounts;

$staffadjustmentcollection->bank_code=$bank_codes;

$bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_codes'");
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	$staffadjustmentcollection->ledger_code=$ledger_code;
	
	
$staffadjustmentcollection->loan_type=$_REQUEST['loan_type'];

$staffadjustmentcollection->voucher_entry();                  	// voucher insert
	
$ledgers_code=array($_REQUEST['loan_type'],$ledger_code);
$ledgers_amount=array($amounts,$amounts);
$ledgers_type=array('credit','debit');

$staffadjustmentcollection->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);	 //voucher_details insert

	
	

?>