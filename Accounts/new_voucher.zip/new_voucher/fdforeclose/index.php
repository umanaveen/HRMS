<?php

require('../../configuration.php');
require('../../user.php');

$user=$_SESSION['user'];
 	
 $memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
require('../main_process.php');
	
$bank_codes=$_REQUEST['bank_code'];
$amounts=$_REQUEST['asl_amount'];
 
 $fdforeclosure=new voucher_process();	// CALL A CLASS NAME
 
	 $fdforeclosure->code=$v_code;
	
$fdforeclosure->voucher_category_code=$_REQUEST['voucher_category_code'];
$fdforeclosure->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
$fdforeclosure->date=date('Y-m-d'strtotime($_REQUEST['curdate']));
$fdforeclosure->member_no=$_REQUEST['member_no'];
$fdforeclosure->name=$_REQUEST['name'];
$fdforeclosure->branch_code=$_REQUEST['branch_code'];
$fdforeclosure->bank_code=$bank_codes;
$fdforeclosure->amount=$amounts;
$fdforeclosure->cheque_no=$_REQUEST['cheque_no'];
$fdforeclosure->cheque_date=date('Y-m-d'strtotime($_REQUEST['cheque_date']));

	$bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_codes'");
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	
	$fdforeclosure->ledger_code=$ledger_codes;
	$fdforeclosure->narration='FD FORE CLOSURE';
    $fdforeclosure->created_by=$user;
    $fdforeclosure->status=1;
	
$fdforeclosure->miscellaneous=$_REQUEST['miscellaneous'];
$fdforeclosure->fd_maturity_amount=$_REQUEST['fd_maturity_amount'];
$fdforeclosure->fd_interest_amount=$_REQUEST['fd_interest_amount'];
$fdforeclosure->fd_amount=$_REQUEST['fd_amount'];
  // 4 values get from fdforeclosure.php

	// $fdforeclosure->voucher_entry(); 
 
 $ledgers_code=array($ledger_codes,$ledger_code);
 $ledgers_amount=array($amounts,$amounts);
 $ledgers_type=array('credit','debit');
 
	// $fdforeclosure->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);
  	

?>