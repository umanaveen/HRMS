<?php
	require("../../configuration.php");
	require("../../phpFunction.php");
	$member_no=$_REQUEST['member_no'];
	$voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
	$ledger_code1=$_REQUEST['ledger_code'];
	$bank_code=$_REQUEST['bank_code'];
	$vou_date=$_REQUEST['vou_entry_date'];
	$vou_date=date('Y-m-d',strtotime($vou_date));
?>
<table class="table table-bordered table-striped" border="1">
<thead>
<?PHP
if($ledger_code1!='Z001')  // its member closed
{	
	?>
<tr>
	<td colspan="3"><center>RECEIPTS</center></td>
	<td colspan="3"><center>PAYMENTS</center></td>
</tr>
<tr>
	<td>Head of Account</td>
	<td colspan="2">Amount</td>
	<td>Head of Account</td>
	<td colspan="2">Amount</td>
</tr>
<tr>
	<td></td>
	<td>Rs.</td>
	<td>P.</td>
	<td></td>
	<td>Rs.</td>
	<td>P.</td>
</tr>
<?PHP
}
else
{
	?>
<tr>
	<td colspan=6><center>RECEIPTS</center></td>
</tr>
<tr>
	
	<td colspan=4>Head of Account</td>
	<td colspan=2>Amount</td>
</tr>
<tr>
	<td colspan=4></td>
	<td>Rs.</td>
	<td>P.</td>
</tr>
<?PHP
}
?>
</thead>
<?php

	$date=$_REQUEST['date'];
		$fdr_no=$_REQUEST['fdr_no'];
		$cheque_no=$_REQUEST['cheque_no'];
		$flag_id='2';
		$fdr_sql="SELECT date,amount FROM fd_balance WHERE member_no='$member_no' and fdr_no='$fdr_no' and flag_id='$flag_id' ";
		$fdr_row=mysql_query($fdr_sql);
		$fdr_res=mysql_fetch_array($fdr_row);
	
			$fd_date=$fdr_res['date'];
			$fd_amount=$fdr_res['amount'];
			$fd_amount=round($fd_amount);
			
			
			 $fd_date=strtotime($fd_date);
			$date=strtotime($date);
			
			$datediff = $date - $fd_date;
			$days=floor($datediff / (60 * 60 * 24));
			
			$interest_rateSql="SELECT 
									(CASE
										WHEN $days BETWEEN from_day AND to_day THEN percentage
                                                                                ELSE
                                                                                  0
									END) as interest_rate
								FROM
								   fdforeclosure_interest_rate ORDER BY interest_rate DESC LIMIT 1";
						
			$interest_rateRow=mysql_query($interest_rateSql);
			$interest_rateRes=mysql_fetch_array($interest_rateRow);
			$fd_interest_rate=$interest_rateRes['interest_rate'];
			
			
	
	$fd_interest_transaction_sql="SELECT SUM(interest_amount) as interest_amount FROM fd_interest_transaction
									WHERE
									fdr_no='$fdr_no' ";
		
	$fd_interest_transaction_row=mysql_query($fd_interest_transaction_sql);
	$fd_interest_transaction_res=mysql_fetch_array($fd_interest_transaction_row);
	
	$fd_interest_paid_amount=$fd_interest_transaction_res['interest_amount'];
	echo $days."<br>";
	echo 'paid_interest'.$fd_interest_paid_amount."<br>";//3027
	


	$fd_interest_amount=($fd_amount*$fd_interest_rate/100)/365;
	echo $fd_interest_amount."<br>";
	$fd_interest_amount=$fd_interest_amount*$days;//1618
	echo $fd_interest_amount;	
	
	if($fd_interest_paid_amount<=$fd_interest_amount)
	{
	$fd_interest_amount=$fd_interest_amount-$fd_interest_paid_amount;
	$miscellenuous=0;
	$fd_interest_amount=round($fd_interest_amount);
	$fd_maturity_amount=$fd_amount+$fd_interest_amount;
	}
	else
	{
		
		$miscellenuous=round($fd_interest_paid_amount-$fd_interest_amount);
		$fd_interest_amount=0;
		$fd_maturity_amount=$fd_amount-$miscellenuous;
	}
	
	
	
	
			
		?>
		<tbody>
		<tr>
					<td>MISC INCOME</td>
			<td align="right"><?php echo $miscellenuous;?><input type="hidden" name="miscellaneous" id="miscellaneous" value="<?php echo $miscellenuous;?>" /></td>
			<td></td>
			<td>Fixed Deposit</td>
			<td align="right"><?php echo $fd_amount;?><input type="hidden" name="fd_amount" id="fd_amount" value="<?php echo $fd_amount;?>" /></td>
			<td></td>
		</tr>
		
		<tr>
			<td>Cheque No: &nbsp; <?php echo $cheque_no;?></td>
			<td align="right"><?php echo $fd_maturity_amount;?><input type="hidden" name="fd_maturity_amount" id="fd_maturity_amount" value="<?php echo $fd_maturity_amount;?>" /></td>
			<td></td>
			<td>Interest paid on FD</td>
			<td align="right"><?php echo $fd_interest_amount;?><input type="hidden" name="fd_interest_amount" id="fd_interest_amount" value="<?php echo $fd_interest_amount;?>" /></td>
			<td></td>
		</tr>
		
		</tbody>
		
		<tfoot>
	<tr>
		<td>Total</td>
		<td><?php echo $fd_amount+$fd_interest_amount;?></td>
		<td></td>
		<td>Total</td>
		<td><?php echo $fd_maturity_amount+$miscellenuous;?></td>
		<td></td>
	</tr>
		</tfoot>
