<?php
require("../../configuration.php");
require("../../phpFunction.php");
$voucher_code=$_REQUEST['voucher_no'];			 
?>
<!DOCTYPE html>
<html>
   <body>
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice">
        <!-- title row -->
		<div class="row">
          <div class="col-xs-12 table-responsive">
		<?php
		   $voucher_sql="SELECT 
								v.code,DATE_FORMAT(date,'%d-%b-%Y') as date,
								v.voucher_category_code,vc.name as voucher_category_name,
								v.slip_no,
								v.ledger_code,l.name as ledger_name,
								v.amount,
								v.description
								FROM 
									voucher v
								JOIN
									voucher_category vc
								ON
									vc.code=v.voucher_category_code
								JOIN
								     ledger l
							    ON
								   l.code=v.ledger_code
								WHERE
								   v.code='$voucher_code'
								 ";
		$voucher_row=mysql_query($voucher_sql);
		$voucher_res=mysql_fetch_array($voucher_row);
	?>
    <table class="table table-striped" id="tblCashVoucher">
		<thead>
			<tr>
			<td colspan="6"></td><td>V.NO : <?php echo "<b>".$voucher_res['code']."</b>";?></td></tr>
				<th colspan="7">
					<center><font size="+1">UCO BANK Employees' Co-operative<br>
					Thrift & Credit Society Ltd., MSCS/CR/42/94<br>
					<center>CHENNAI-600 001.</font></center>
				</th>
		</thead>
	<tbody>
		<tr>
			<td>
				<!-- Code: -->
				Slip No:<?php echo "&nbsp;".$voucher_res['slip_no']."&nbsp;"; ?>
			</td>
			<td colspan="5">
				<center><?php echo "<u>".$voucher_res['voucher_category_name']."</u>"; ?></center>
			</td>
			<td align="right"> 
				Date: <?php echo $voucher_res['date'];?>
			</td>
		</tr>
		<tr>
		<td><br>
		</tr>
					
		<tr>
			<td colspan="7"><font size="+1" >DEBIT &nbsp; A/c </font>
			<font size="+1" >&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $voucher_res['ledger_name'];?></font></td>
		</tr>
		<tr>
			<td colspan="7"><font size="+1" >Rs. </font><?php $amount=$voucher_res['amount']; echo $amount;?>
			<font size="+1" >(Rupees    </font> <?php $intAmount=(int)$amount; echo convert_number_to_words($intAmount) ?>&nbsp;Only )</td>
			
		</tr>
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td colspan="6"><font size="+1" >being the amount</font></td><td colspan="1"> 
			<?php echo $voucher_res['description'];?></td>
		</tr>
		
		
	</tbody>
	<tfoot>
		<tr>
			<td><br></td>
			
		</tr>
		<tr>
		<td colspan="6"></td>
		<td>Received by</td></tr>
		<tr colspan="6">
			<td>Rs. <?php echo $amount; ?></td><td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>Prepared by</td>
				<td>Secretary</td>
				<td colspan="2"></td>
				<td>Signature</td>
				
		</tr>
	</tfoot>
															
</table>
				
            </div>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

  </body>
</html>
