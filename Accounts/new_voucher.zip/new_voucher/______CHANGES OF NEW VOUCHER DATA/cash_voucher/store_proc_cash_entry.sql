	// Cash Entry Insert And Update Stored procedure   
	// Bala

delimiter //
create procedure cash_vouch_entry (id int,vou_cat_code varchar(50),dates date,slip_id int,ledger_codes varchar(50),amount float(50,2),description varchar(255),user_id int(11))
begin

DECLARE vouch_codes varchar(255);

if id=0 then
 
	SELECT concat('VOU-',id+1) as vouch_codes FROM voucher order by id desc limit 1;
 
SET @c1=CONCAT("insert into voucher(code,voucher_category_code,date,slip_no,ledger_code,amount,description,status,created_by,created_on) values ('",vouch_codes,"','",vou_cat_code,"','",dates,"','",slip_id,"','",ledger_codes,"','",amount,"','",description,"','",1,"','",user_id,"',now())");
PREPARE stmt1 from @c1;
		EXECUTE stmt1;
					
SET @c2=concat("insert into voucher_detail(voucher_code,ledger_code,description,payment,status,created_by,created_on) values ('",vouch_codes,"','",ledger_codes,"','",description,"','",amount,"','",1,"','",user_id,"',now())");
	PREPARE stmt12 from @c2;
		EXECUTE stmt12;
		
		DEALLOCATE PREPARE stmt1;
		DEALLOCATE PREPARE stmt12;	
else

SET @c22=concat("update voucher set voucher_category_code='",vou_cat_code,"',date='",dates,"',slip_no='",slip_no,"',ledger_code='",ledger_codes,"',amount='",amount,"',description='",description,"',status='",1,"',modified_by='",user_id,"',modified_on=now where code='",vouch_code,"'");
	PREPARE stmt2 from @c22;
		EXECUTE  stmt2;
		
SET @d1=concat("Delete from voucher_detail where voucher_code='",vouch_code,"'");		
	PREPARE delete1 from @d1;
		EXECUTE  delete1;	
	
SET @in1=concat("insert into voucher_detail(voucher_code,ledger_code,description,payment,status,created_by,created_on) values ('",vouch_code,"','",ledger_codes,"','",description,"','",amount,"','",1,"','",user_id,"',now())");
	PREPARE insert1 from @in1;
		EXECUTE insert1;
			
			DEALLOCATE PREPARE stmt2;
			DEALLOCATE PREPARE delete1;
			DEALLOCATE PREPARE insert1;
end if;
end //
delimiter //