<?php 
require('../../configuration.php');
require('../../user.php');
	$user=$_SESSION['user'];

  $cash_cat_code=$_REQUEST['cash_cat_code'];
  $vouch_id=$_REQUEST['id'];
  $vouch_det=$_REQUEST['date'];
  $vouch_date=date('Y-m-d',strtotime($vouch_det));
  $vouch_slip_id=$_REQUEST['slip_no'];
  $vouch_ledger_code=$_REQUEST['ledger_code'];
  $vouch_amount=$_REQUEST['amount'];
  $vouch_description=$_REQUEST['description'];
  $voucher_code=$_REQUEST['vouch_code'];

	  if($voucher_code=='')
	  {
		$vouch_codes=mysql_fetch_array(mysql_query("select code from voucher order by id desc limit 1"));
		$vous_code=$vouch_codes['code'];
		if($vous_code=='')
		{
			$vouch_code='Vou-001';
		}
		else
		{
		
		$ch=split('-',$vous_code);
		$code_name=$ch[0];  $incs_code=$ch[1]+1;
		if($incs_code<100)
		{  $inc_code=str_pad($incs_code,3,'0',STR_PAD_LEFT); 	}
		 
			$vouch_code= $code_name.'-'. $inc_code;
	    }
	   }
	  else
	  {
		   $vouch_code=$voucher_code;
	  }



class cash_voucher
{ 
	public function cash_vouch($vouch_id,$cash_cat_code,$v_date,$vouch_slip_id,$vouch_ledger_code,$vouch_amount,$vouch_description,$user) 
		{
		 
		 echo "call cash_vouch_entry('$vouch_id','$cash_cat_code','$v_date','$vouch_slip_id','$vouch_ledger_code','$vouch_amount','$vouch_description','$user')";
		/*  $cash_entry=mysql_query("call cash_vouch_entry('$vouch_id','$cash_cat_code','$v_date','$vouch_slip_id','$vouch_ledger_code','$vouch_amount','$vouch_description','$vouch_code','$user')");
		 if($cash_entry)
		 {
			 header('location:../../index.php');	
		 } */
		}
 
}

$obj_cash=new cash_voucher(); // New object will be created here 
	 $obj_cash->cash_vouch($vouch_id,$cash_cat_code,$vouch_date,$vouch_slip_id,$vouch_ledger_code,$vouch_amount,$vouch_description,$user); 

?>