<?php 
require('../../configuration.php');
require('../../user.php');
$user=$_SESSION['user']; //user id

  $cash_cat_code=$_REQUEST['cash_cat_code'];
  $vouch_id=$_REQUEST['id'];  // Vouc_id
  $vouch_det=$_REQUEST['date'];
  $vouch_date=date('Y-m-d',strtotime($vouch_det));
  $vouch_slip_id=$_REQUEST['slip_no'];
  $vouch_ledger_code=$_REQUEST['ledger_code'];
  $vouch_amount=$_REQUEST['amount'];
  $vouch_description=$_REQUEST['description'];
	
							// Only update a voucher table particular row
	$vou_update=mysql_query("update voucher set date='$vouch_date',voucher_category_code='$cash_cat_code',slip_no='$vouch_slip_id',ledger_code='$vouch_ledger_code',amount='$vouch_amount',description='$vouch_description',status='1' where code='$vouch_id'");
							// Delete voucher detail table row using vou code
	$vou_det=mysql_query("delete from voucher_detail where voucher_code='$vouch_id'");
							// Voucher Detail Entry
		$voucherDetail_sql="SELECT code FROM voucher_detail ORDER BY id DESC";
		$voucherDetail_row=mysql_query($voucherDetail_sql);
		$voucherDetail_check=mysql_num_rows($voucherDetail_row);
		
		if($voucherDetail_check<1)
		{
			$voucher_detail_code='VOUDET-001';
		}
		else
		{
			$voucherDetail_res=mysql_fetch_array($voucherDetail_row);
			$voucherDetail_code=$voucherDetail_res['code'];
			$vd_splitValue=explode("-",$voucherDetail_code);
			$num=$vd_splitValue[1];
			$num=$num+1;
			if($num<100)
			{
				$num=str_pad($num,3,"0",STR_PAD_LEFT);
			}
			
			$voucher_detail_code=$vd_splitValue[0]."-".$num;
		}
			
			mysql_query("INSERT INTO voucher_detail(code,voucher_code,ledger_code,description,receipt,payment,status,modified_by,modified_on)VALUES('$voucher_detail_code','$vouch_id','$vouch_ledger_code','This is spend cash for some expenses','','$vouch_amount','1','$user',NOW())");
		
		//echo "INSERT INTO voucher_detail(code,voucher_code,ledger_code,description,receipt,payment,status,modified_by,modified_on)VALUES('$voucher_detail_code','$vouch_id','$vouch_ledger_code','This is spend cash for some expenses','','$vouch_amount','1','$user',NOW())";
												// Account Entry Tabke
	
		$suc=mysql_query("update account_entry set search_no='$vouch_slip_id',date='$vouch_date',ledger_code='$vouch_ledger_code',amount='$vouch_amount',type='debit',modified_by='$user',modified_on=now() where reference='$vouch_id'");
	//	echo "update account_entry set search_no='$vouch_slip_id',date='$vouch_date',ledger_code='$vouch_ledger_code',amount='$vouch_amount',type='debit',modified_by='$user',modified_on=now() where reference='$vouch_id'";
			
 if($suc)
 {
	echo 1;	 
 }
 else
 {
	 echo 0;
 }
  
  ?>
 