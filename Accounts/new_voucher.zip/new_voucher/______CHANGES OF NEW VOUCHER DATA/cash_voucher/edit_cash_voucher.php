<?php 
require('../../configuration.php');
$date=date('d-m-Y');
$cur_date=date('m-d-Y',strtotime($date));
$voucher_no=$_REQUEST['voucher_no'];
?>
<form id="edit_cash_form">
<table class="table table-bordered table-hover">
<thead>
	<tr style="font-weight:bold;"><center>CASH VOUCHER</center></tr>
</thead>
<tbody>
		<?php
			if($voucher_no!='')
			{
				?><input type="hidden" id="id" name="id" value="<?php echo $voucher_no; ?>"><?PHP
			}
		else
			{
				?><input type="hidden" id="id" name="id" value="<?php echo 0; ?>"><?PHP
			}
		?>
<tr>
	<tr>
		<td width="50%">Category Code</td>
		<td>
		<input type="hidden" name="cash_cat_code" id="cash_cat_code" value="<?php echo "CAT-001"; ?>" class="form-control" readonly="true"/>
		</td>
	</tr>
	<td width="50%">Date</td>
	<td>
		<div class="input-group"><div class="input-group-addon"><i class="fa fa-calendar"></i></div>
			<div id="cash_vouch_date" class="input-append date">
					<div class="input-group" style="width:100%;">
					<input type="text" class="add-on form-control" id="date" name="date" title=" Date" value="<?php echo date("d-m-Y"); ?>" />
				
						</div>
						<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
			</div>
		</div>
	</td>
	</tr>
	<tr>
		<td width="50%">Slip No</td>
		<td>
		<input type="text" name="slip_no" id="slip_no" value="" class="form-control" />
		</td>
	</tr>
	

	<tr>
		<td>Ledger</td>
	<td>
	<select class="form-control select2" id="ledger_code" name="ledger_code">
			<?php
				$ledger_sql="SELECT code,name FROM ledger";
				$ledger_row=mysql_query($ledger_sql);
				while($ledger_res=mysql_fetch_array($ledger_row))
				{
			?>
				<option value="<?php echo $ledger_res['code'];?>"><?php echo $ledger_res['name'];?></option>
			<?php
			
				}	
			?>
		
			
	</select>
	</td>
	</tr>
	<tr>
		<td>Amount</td>
		<td>
			<input type="text" name="amount" id="amount" value="" class="form-control" />
		</td>
	</tr>
	<tr>
		<td>Description</td>
		<td>
			<textarea rows="4" class="form-control" id="description" name="description"></textarea>
		</td>
	</tr>
</tbody>
	
</table>


</form>
<div>
<input type="submit" style="float:right;margin-right:40px;" name="cash_edit" value="Update" onclick="edit_cash_entry(1)" class="btn btn-success btn-md">
<div>
<script>
	$(document).ready(function () {
	
		$('#cash_vouch_date').datetimepicker({
		format: "dd-MM-yyyy"
		});
	});
	
	function edit_cash_entry(s)
	{	
		var id=1;
		var data=$('form').serialize();
		$.ajax({
				type: "GET",
				url: "new_voucher/cash_voucher/update_cash_entry.php",
				data: "id="+id, data,
				success: function(data) {
					//alert(data);
					if(data==1)
							{
							alert("Vocuher Will be Edited");
								new_voucher();
							}
							else
							{
							alert("Vocuher Not Will be Edited");
								new_voucher();
							}
						}
			});
	}
	
</script>