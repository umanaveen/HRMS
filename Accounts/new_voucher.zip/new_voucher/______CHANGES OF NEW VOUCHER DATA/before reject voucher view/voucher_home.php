<?php 
require('../configuration.php');
require('../user.php');
$user_id=$_SESSION['user'];
?>

<div class="box box-success ">
	<div class="box-body no-padding" style="margin:1px;">
	<div class="col-sm-1">
	<input type="button" class="btn btn-warning" name="home_voucher" id="home_voucher" onclick="home_voucher()" value="HOME"/>
	</div>
	<div class="col-sm-5">
	<select class="form-control vouch_search" id="search_voucher_no" name="search_voucher_nos" style="">
	<option value="">Choose Voucher Number</option>
	<?php

	$search_vouc=mysql_query("SELECT code,voucher_purpose_code,voucher_category_code FROM voucher where created_on<now() and status in (2,3)order by id desc limit 0,50");
	while($voucher_list=mysql_fetch_array($search_vouc))
	{  
		$vou_code=$voucher_list['code'];
	?>
	<option value="<?php echo $vou_code; ?>"><?php echo $vou_code; ?></option>
	<?php 
	}
	?>
	</select>
	</div> 
	<div class="col-sm-2">
	<span class="input-group-btn">
	<button class="btn btn-info btn-flat" type="button" onClick="voucher_search()">Search</button>
	</span>
	</div>
	<br/>
	</div> 
</div>		<!-- box box-primary-->

<div id="voucher_home">
<div class="newmember_adj" style="width:100%;height:100%;">		
<div class="newmember_adj_left" style="width:25%;height:480px;float:left;margin-top:1px;overflow:scroll;">
					
<!-- Side Screeen of page -->
<div class="box box-primary">
<div class="box-body">
<ul class="nav nav-pills" style="float:left; width:100%; " >	
<li style="background-color:orange; width:100%;">
<p style="text-align:center; margin-top:10px;font-family: none;font-style:inherit;font-size: large;font-variant-caps:unset; font-size:14px;font-weight:bold;text-align:center;">Voucher Waiting List</p></li>
<?php
$vouch_query="SELECT code FROM voucher where status=1 order by id desc";
$vouch_row=mysql_query($vouch_query);
$s1=1;
while($voucher_res=mysql_fetch_array($vouch_row))
{
	$code=$voucher_res['code'];
?>
<li style="border-top:1px solid #ddd;cursor:pointer;width:100%;text-transform:uppercase;line-height:20px;font-weight:bold; position:relative;" class="active1" id="<?php echo $s1;?>">
<?php echo "Vou Code:&nbsp".$voucher_res['code'];?>
<div style="float:right;">
<button class="btn btn-primary" id="" value="<?php echo $code;?>" onclick="edit(this.value)"><i class="fa fa-pencil"></i></button>
<button class="btn btn-success" id="" value="<?php echo $code;?>" onClick="view(this.value)"><i class="fa fa-eye"></i></button>
</div>
<?php $s1++; ?>
</li>
<?php
}    
?>
</ul>
</div>                   <!-- box-body close-->
</div>		
</div>
<div class="box box-primary" id="newmember_adj_right" style="width:75%;float:left;overflow:scroll;height:500px;">

<?php 

$voucher=mysql_fetch_array(mysql_query("SELECT code,date,voucher_category_code,voucher_purpose_code,slip_no,reference_voucher,member_no, name,branch_code,reference_no,ledger_code,amount,bank_code,cheque_no,cheque_date,description,narration,status FROM voucher  order by id desc limit 0,1"));
$date=$voucher['date'];
$voucher_code=$voucher['code'];
?>
<table class="table table-bordered table-hover" style="margin:1px;" >

<thead style="FONT-SIZE: 14px;font-family: none;">
<center>
	<h4>UCO</h4>
	(UCO BANK EMPLOYEES' CO-OP THRIFT & CREDIT SOCIETY LTD..,MSCS/CR/42/94.)<br/>
</center>
</thead>

<tbody>
<tr>
<td>Voucher Code</td><td><?php echo $voucher_code;?></td><td>Date</td><td><?php echo $date;?></td>
</tr>
<tr>
<td>Member No - Name</td><td><?php echo $voucher['member_no'].'-'.$voucher['name']; ?></td>
<td>Branch </td><td><?php echo $voucher['branch_code'];?></td>
</tr>

<tr>
<td>Amount</td><td style="text-align:right"><?php echo round($voucher['amount']); ?></td>
<td>Bank <br> Cheque No</td><td><?php echo $voucher['bank_code']; ?><br><?php echo $voucher['cheque_no']; ?></td>
</tr>

<tr><th colspan="2">Ledger Code</th><th>Receipt</th><th>Payment</th></tr>
<?php

$v_sql=mysql_query("SELECT ledger_code,reference,amount,type,narration,status FROM voucher_detail WHERE 
voucher_code='$voucher_code'");

$credit_t=0;
$debit_t=0;

while($vou_det=mysql_fetch_array($v_sql))
{
	$ledger=$vou_det['ledger_code'];	
	$led_name=mysql_fetch_array(mysql_query("SELECT name FROM ledger WHERE code='$ledger'"));
	$ledger_name=$led_name['name'];
?>
<tr>	
	<td colspan="2"><?php echo $ledger.'-'.$ledger_name; ?></td>	
	<td style="text-align:right">
	<?php 
	if($vou_det['type']=='credit')
	{
		$credit=$vou_det['amount'];
		echo round($credit);
		$credit_t=$credit_t+$credit;
	}
	?>
	</td>
		
	<td style="text-align:right">
	<?php
	if($vou_det['type']=='debit')
	{
		$debit=$vou_det['amount'];
		echo round($debit);
		$debit_t=$debit_t+$debit;
	}
	?>
	</td>
</tr>		
	
<?php
}
?>
<tr><td colspan="2">Total</td><td style="text-align:right"><?php echo $credit_t; ?></td>
								<td style="text-align:right"><?php echo $debit_t; ?></td>
								</tr>
</tbody>
</table>
</div>
</div>
</div>

 <!-- Page js file will be there..@! -->

<?php require('edit_voucher_page.js'); ?> 
