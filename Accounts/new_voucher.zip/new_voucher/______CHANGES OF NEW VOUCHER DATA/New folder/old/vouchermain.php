<?php
require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];

$voucher_code=$_REQUEST['voucher_code'];
$voucher_detail=mysql_fetch_array(mysql_query("select * from voucher where code='$voucher_code'"));
$date=$voucher_detail['date'];
$category_code=$voucher_detail['voucher_category_code'];
$purpose_code=$voucher_detail['voucher_purpose_code'];



$vd_sql=mysql_query("select * FROM voucher_detail WHERE voucher_code='$voucher_code'");

while($vd_res=mysql_fetch_array($vd_sql))
{
	$ledger_code[]=$vd_res['ledger_code'];
	$amount[]=$vd_res['amount'];
	$type[]=$vd_res['type'];
	$reference[]=$vd_res['reference'];
	$narration[]=$vd_res['narration'];
	
}

mysql_query("UPDATE voucher SET status=2 WHERE code='$voucher_code'");
mysql_query("UPDATE voucher_detail SET status=2 WHERE voucher_code='$voucher_code'");

	
$length=count($ledger_code);

require('main_process.php');
$vou_obj=new voucher_approve();

for($i=0;$i<$length;$i++)
{
	$memsql=mysql_query("SELECT concat('ACC-',id+1) as acc_code FROM account_entry order by id desc limit 0,1");
	$mem_res=mysql_fetch_array($memsql);
	$acc_code=$mem_res['acc_code'];	
	
	$amount[$i];
	echo $ledger_code[$i];
	
	if($category_code=='CAT-004')
	{
	$sql="INSERT INTO account_entry(code,sequence,main_entity,main_entity_type,reference,	search_no,date,ledger_code,amount,type,bank_code,cheque_no,cheque_date,narration,created_by,created_on)VALUES('$acc_code','$i','VOUCHER','ADJUSTMENT RECEIPT','$voucher_code','$reference[$i]','$date','$ledger_code[$i]','$amount[$i]',
	'$type[$i]','','','','$narration[$i]','$user_id',NOW())";
	}
	else if($category_code=='CAT-005')
	{
	$sql="INSERT INTO account_entry(code,sequence,main_entity,main_entity_type,reference,	search_no,date,ledger_code,amount,type,bank_code,cheque_no,cheque_date,narration,created_by,created_on)VALUES('$acc_code','$i','VOUCHER','ADJUSTMENT SLIP','$voucher_code','$reference[$i]','$date','$ledger_code[$i]','$amount[$i]',
	'$type[$i]','','','','$narration[$i]','$user_id',NOW())";
	}
	
	mysql_query($sql) or die("account_entry ".mysql_error());

	if($ledger_code[$i]=='E003') 		//srf data
		{
			$vou_obj->vou_date=$date;
			$vou_obj->srf_member_no=$reference[$i];
			$vou_obj->srf_ledger_code=$ledger_code[$i];
			$vou_obj->srf_type=$type[$i];
			$vou_obj->srf_amount=$amount[$i];
			$vou_obj->voucher_code=$voucher_code;			
			
			if($purpose_code=='PUR-001')
			{				
				$vou_obj->narration='OPN BAL';
			}
			else if($purpose_code=='PUR-004')
			{				
				$vou_obj->narration='BULK. COL';
			}
			
			$vou_obj->srf_insert(); 
		}
		else if($ledger_code[$i]=='A003') 	//thrift data
		{
			$vou_obj->vou_date=$date;
			$vou_obj->thrift_member_no=$reference[$i];
			$vou_obj->thrift_ledger_code=$ledger_code[$i];
			$vou_obj->thrift_type=$type[$i];
			$vou_obj->thrift_amount=$amount[$i];
			$vou_obj->voucher_code=$voucher_code;
			
			if($purpose_code=='PUR-001')
			{				
				$vou_obj->narration='OPN BAL';
			}
			else if($purpose_code=='PUR-004')
			{				
				$vou_obj->narration='BULK. COL';
			}
			
			$vou_obj->thrift_insert(); 
		}
		else if($ledger_code[$i]=='D001')	//share data
		{
			$vou_obj->vou_date=$date;
			$vou_obj->share_member_no=$reference[$i];
			$vou_obj->share_ledger_code=$ledger_code[$i];
			$vou_obj->share_type=$type[$i];
			$vou_obj->share_amount=$amount[$i];
			$vou_obj->voucher_code=$voucher_code;
			if($purpose_code=='PUR-001')
			{				
				$vou_obj->narration='OPN BAL';
			}			
			
			$vou_obj->share_insert(); 
		}
		else if($ledger_code[$i]=='F001')	//surety_int
		{
			$vou_obj->vou_date=$date;
			$vou_obj->voucher_code=$voucher_code;
			$vou_obj->surety_int_member_no=$reference[$i];
			$vou_obj->surety_int_ledger_code=$ledger_code[$i];
			$vou_obj->surety_int_type=$type[$i];
			$vou_obj->surety_int_amount=$amount[$i];
			
			if($purpose_code=='PUR-003')
			{				
				$vou_obj->narration='ADJ. COL';
			}
			else if($purpose_code=='PUR-004')
			{				
				$vou_obj->narration='BULK. COL';
			}
			$vou_obj->surety_int_insert();  
		}
			else if($ledger_code[$i]=='G001')	//surety_pri
		{
			$vou_obj->vou_date=$date;
			$vou_obj->voucher_code=$voucher_code;
			$vou_obj->surety_member_no=$reference[$i];	
			$vou_obj->surety_ledger_code=$ledger_code[$i];
			$vou_obj->surety_type=$type[$i];
			$vou_obj->surety_amount=$amount[$i];
			if($purpose_code=='PUR-003')
			{				
				$vou_obj->narration='ADJ. COL';
			}
			else if($purpose_code=='PUR-004')
			{				
				$vou_obj->narration='BULK. COL';
			}
			$vou_obj->surety_insert(); 
		}
		else if($ledger_code[$i]=='F002')	//fest_int data
		{
			$vou_obj->vou_date=$date;
			$vou_obj->voucher_code=$voucher_code;
			$vou_obj->fest_int_type=$type[$i];			
			$vou_obj->fest_int_ledger_code=$ledger_code[$i];			
			$vou_obj->fest_int_member_no=$reference[$i];
			$vou_obj->fest_int_amount=$amount[$i];
			
			if($purpose_code=='PUR-003')
			{				
				$vou_obj->narration='ADJ. COL';
			}
			else if($purpose_code=='PUR-004')
			{				
				$vou_obj->narration='BULK. COL';
			}
			$vou_obj->fest_int_insert(); 
			
		}
		else if($ledger_code[$i]=='G002')	//fest data
		{
			$vou_obj->fest_member_no=$reference[$i];
			$vou_obj->fest_ledger_code=$ledger_code[$i];
			$vou_obj->fest_type=$type[$i];
			$vou_obj->fest_amount=$amount[$i];
			$vou_obj->voucher_code=$voucher_code;
			
			if($purpose_code=='PUR-003')
			{				
				$vou_obj->narration='ADJ. COL';
			}
			else if($purpose_code=='PUR-004')
			{				
				$vou_obj->narration='BULK. COL';
			}
			$vou_obj->fest_pri_insert(); 
		}
		else if($ledger_code[$i]=='I002')	//scr data
		{
			$vou_obj->vou_date=$date;
			$vou_obj->scr_member_no=$reference[$i];
			$vou_obj->scr_ledger_code=$ledger_code[$i];
			$vou_obj->scr_type=$type[$i];
			$vou_obj->scr_amount=$amount[$i];
			$vou_obj->voucher_code=$voucher_code;
			$vou_obj->scr(); 
		}
		else if($ledger_code[$i]=='I001')	//sdr data
		{
			$vou_obj->vou_date=$date;
			$vou_obj->sdr_member_no=$reference[$i];
			$vou_obj->sdr_ledger_code=$ledger_code[$i];
			$vou_obj->sdr_type=$type[$i];
			$vou_obj->sdr_amount=$amount[$i];
			$vou_obj->voucher_code=$voucher_code;
			$vou_obj->sdr(); 
		}
		else									//other data
		{
			$other_member_no[]=$reference[$i];
			$other_ledger_code[]=$ledger_code[$i];
			$other_type[]=$type[$i];
			$other_amount[]=$amount[$i];	
			$vou_obj->voucher_code=$voucher_code;
			//$vou_obj->other();	
		}
}



?>