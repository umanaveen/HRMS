<?php

require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];

$memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
require('../main_process.php');
$fdloan=new voucher_process();

$bank_codes=$_REQUEST['bank_code'];

$fdloan->voucher_category_code=$_REQUEST['vou_cat'];
$fdloan->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
$fdloan->code=$v_code;
$fdloan->date=date("Y-m-d",strtotime($_REQUEST['fd_date']));
$fdloan->member_no=$_REQUEST['member_no'];
$fdloan->name=$_REQUEST['name'];
$fdloan->branch_code=$_REQUEST['branch_code'];
$fdloan->amount=$_REQUEST['amount'];
$fdloan->bank_code=$fdloan;

$bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_codes'");
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	$fdloan->ledger_code=$ledger_code;
	
$fdloan->cheque_no=$_REQUEST['cheque_no'];
$fdloan->cheque_date=$_REQUEST['cheque_date'];
$fdloan->description=$_REQUEST['description'];
$fdloan->narration='FD LOAN';	


$fdloan->voucher_entry();



$fdloan->loan_no=$_REQUEST['loan_no'];
$fdloan->fd_loan_date=$_REQUEST['fd_loan_date'];
$fdloan->fd_interest_rate=$_REQUEST['fd_interest_rate'];
$fdloan->fd_eligible_amount=$_REQUEST['fd_eligible_amount'];
$fdloan->fd_loan_one_int_amount=$_REQUEST['fd_loan_one_int_amount'];
$fdloan->fd_loan_amount=$_REQUEST['fd_loan_amount'];
$fdloan->fd_loan_int_amt=$_REQUEST['fd_loan_int_amt'];
$fdloan->principal=$_REQUEST['principal'];
$fdloan->interest=$_REQUEST['interest'];

$ledgers_code=array('');
$ledgers_amount=array('');
ledgers_type=array('');

$fdloan->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);

?>