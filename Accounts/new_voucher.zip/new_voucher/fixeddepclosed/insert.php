<?php
require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];
$dates=date('d-m-Y');
$date=date('d-m-Y',strtotime($dates));

$vou_category_id=$_REQUEST['vou_cat_code'];
$vou_pur_id=$_REQUEST['vouc_pur_id'];


$vouch_pur=mysql_query("select code from voucher_purpose where id='$vou_pur_id' and voucher_category_code='$vou_category_id'"); // get the purpose code 
$voucher_pur_code_count=mysql_num_rows($vouch_pur);
$vouch_pur_code=mysql_fetch_array($vouch_pur);  	// Get the data
$voucher_purp_code=$vouch_pur_code['code'];   		// voucher purpose code 
if($voucher_pur_code_count>0)  						// Voucher count greater than 0 -- Success function
{
	if($voucher_purp_code=='PUR-005') 				// New member Creation of Adjustment receipt
	{
 ?>
 
 <style>
 .input-group{
	 autocomplete:off;
 }
 </style>
 <div>
<input type="button" name="submit" style="float:right;margin-right:50px;" onclick="fixeddepositclosed()"  value="Save" class="btn btn-primary btn-sm" autocomplete="off" />
</div>

 <h4><center>FIXED DEPOSIT CLOSED</center></h4>
  <table class="table table-bordered table-hover">
<input type="hidden" name="voucher_category_code" id="voucher_category_code" value="<?php echo $vou_category_id; ?>">
<tr>
			<td>Date</td>
			<td><div class="input-group"><div class="input-group-addon"><i class="fa fa-calendar"></i></div>
					 <div id="datetimepicker1" class="input-append date">
     				<input type="text" class="add-on form-control"  value="<?php echo $date; ?>" id="curdate" name="curdate" autocomplete="off">
      				<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      				</div></div>
			</td>
</tr>
<tr>
	<td>Member No</td>
	<td><input type="text" class="form-control" id="member_no" name="member_no" value="" onchange="checkMember(this.value)" autocomplete="off"/>
		<script>
			function checkMember(v)
			{
				$.get('/UCO/new_voucher/checkMember.php?member_no='+v,function(data) { 
						var splitData=data.split("=");
						$('#name').val(splitData[0]);
						$('#branch_code').val(splitData[1]);
						$('#branch_name').val(splitData[2]);
				});
			}
		</script>
	</td>
</tr>


<tr>
	<td>Name</td>
	<td><input type="text" class="form-control" id="name" name="name" value="" readonly="true" autocomplete="off"/></td>
</tr>


<tr>
	<td>Branch</td>
	<td>
	<input type="hidden" id="branch_code" name="branch_code" value="" />
	<input type="text" class="form-control" id="branch_name" name="branch_name" value="" readonly="true" autocomplete="off"/></td>
</tr>

<tr>
				<td>Bank</td>
				<td><select class="form-control select2" id="bank_code" name="bank_code">
						<option value="">Select Bank</option>
						<?PHP
							$bank_sql="SELECT code,name FROM bank ";
							$bank_row=mysql_query($bank_sql);
							while($bank_res=mysql_fetch_array($bank_row))
							{
						?>
							<option value="<?php echo $bank_res['code'];?>"><?php echo $bank_res['name'];?></option>
						<?php
							}
						?>
					</select>
				</td>
		</tr>

		<tr>
			<td>
				Amount
			</td>
			<td>
				<input type="text" id="asl_amount" name="asl_amount" class="form-control" value="" autocomplete="off" />
			</td>
		</tr>		
		<tr>
			<td>
				Cheque No
			</td>
			<td>
				<input type="text" id="cheque_no" name="cheque_no" class="form-control" value="" autocomplete="off"/>
			</td>
		</tr>
		<tr>
			<td>Cheque Date</td>
			<td><div class="input-group"><div class="input-group-addon"><i class="fa fa-calendar"></i></div>
					 <div id="datetimepicker1" class="input-append date">
     				<input type="text" class="add-on form-control"  value="" id="cheque_date" name="cheque_date" autocomplete="off">
      				<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
      				</div></div>
			</td>
		</tr>
		
		<script>
						$(function() {
    $('#datetimepicker1').datetimepicker({
    format: "dd-MM-yyyy"
    });
			});
			$(function() {
    $('#curdate').datetimepicker({
    format: "dd-MM-yyyy"
    });
			});
			
			$("#member_no").bind('keypress', function (evt) {
     evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;										
	});	
	$("#cheque_no").bind('keypress', function (evt) {
     evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;										
	});	
		
			</script>
	<tr>
			<td>Description</td>
			<td><textarea rows="4"  class="form-control" id="description" name="description" autocomplete="off">
				</textarea></td>
	</tr>
		<tr>
				<td>Ledger</td>
				<td><select class="form-control select2" id="ledger_code" name="ledger_code" onchange="checkScr(this.value)" autocomplete="off">
						<option value="">Select Ledger</option>
						<?PHP
							$ledger_sql="SELECT code,name FROM ledger";
							$ledger_row=mysql_query($ledger_sql);
							while($ledger_res=mysql_fetch_array($ledger_row))
							{
						?>
							<option value="<?php echo $ledger_res['code'];?>"><?php echo $ledger_res['name'];?></option>
						<?php
							}
						?>
					</select>
				</td>
		</tr>
		
<script>		
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< if scr release  branch or member >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>		
				function checkScr(v)
				{
					var member_no=$('member_no').val();   ///its for branch release
					if((member_no=='' && v=='I002'))
					{
						data='<select class="form-control select2" id="fdr" name="scr_branch" data-placeholder="Select Branch" onchange="changeBranch(this.value)" style="width: 100%;"><?php $branch_sql="SELECT code,name FROM branch"; $branch_row=mysql_query($branch_sql); while($branch_res=mysql_fetch_row($branch_row)) { ?> <option value="<?php echo $branch_res[0];?>"><?php echo $branch_res[0]."-".$branch_res[1];?></option><?php } ?></select>';
						
							$('#changeBranch').html(data);
						  $('.select2').select2();
					}
					/* else if(v=='I001')		///its for sundry debtors release
					{
						data='<select class="form-control select2" id="fdr" name="scr_branch" data-placeholder="Select Voucher" onchange="changeBranch(this.value)" style="width: 100%;"><?php $scr_sql="SELECT `reference`,`amount` FROM `sundry_debtors` WHERE `flag_id`=19"; $scr_row=mysql_query($scr_sql); while($scr_res=mysql_fetch_row($scr_row)) { ?> <option value="<?php echo $scr_res[0];?>"><?php echo $scr_res[0]."-".$scr_res[1];?></option><?php } ?></select>';
						
							$('#changeBranch').html(data);
						  $('.select2').select2();
					} */
					else		///its for member release
					{
						data='<select class="form-control select2" id="fdr" name="scr_branch" data-placeholder="Select Branch" onchange="changeBranch(this.value)" style="width: 100%;"><?php $scr_sql="SELECT `reference`,`amount` FROM `sundry_creditors` WHERE `flag_id`=19"; $scr_row=mysql_query($scr_sql); while($scr_res=mysql_fetch_row($scr_row)) { ?> <option value="<?php echo $scr_res[0];?>"><?php echo $scr_res[0]."-".$scr_res[1];?></option><?php } ?></select>';
						
							$('#changeBranch').html(data);
						  $('.select2').select2();
					}
				}
				function changeBranch(v)
				{
					$('#branch_code').val(v);
					$('#branch_name').val(v);
				}
</script>
		<tr>
			<td>Branch/Member</td>
			<td> 
					<div id="changeBranch">
					
					</div>
					
					
			</td>
		</tr>
<!--<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>-->	
<tr>
	<td width="50%">Voucher Purpose</td>
	<td>
		<input type="hidden" class="form-control" id="voucher_purpose_code" name="voucher_purpose_code" value="PUR-005">
		<input type="text" class="form-control" id="voucher_purpose_name" name="voucher_purpose_name" value="FIXED DEPOSIT CLOSE" onclick="changeHeads(this.value)" readonly="true" autocomplete="off">

	
		<script>
						
			function changeHeads(u)
			{
				var v=$('#voucher_purpose_code').val(); 
				var vou_entry_date=$('#curdate').val();
				var member_no=$('#member_no').val();
				var ledger_code=$('#ledger_code').val();
				var branch_code=$('#branch_code').val();
				var date=$('#date').val();
				var cheque_no=$('#cheque_no').val();
				var asl_amount=$('#asl_amount').val();
				var bank_code=$('#bank_code').val();
				$.ajax({
				type: "GET",
				url: "/UCO/new_voucher/fixeddepclosed/change_fd_close.php",
				data: "voucher_purpose_code="+v+"&member_no="+member_no+"&branch_code="+branch_code+"&date="+date+"&cheque_no="+cheque_no+"&asl_amount="+asl_amount+"&ledger_code="+ledger_code+"&bank_code="+bank_code+"&vou_entry_date="+vou_entry_date,						
				success: function(data)
				{
					$('#changeHeads').html(data);
				}
				});				
			}
	
		</script>
	</td>
</tr>
		
</table>
<div id="changeHeads">
</div>
<tr style="float:right;margin-right:50px;">
<input type="submit" name="fddepclose" value="Save" onclick="fddepclose_mem(1)" class="btn btn-primary btn-sm">
</tr>
</form>
<?php 
	}
}
?>
<script>
function fddepclose_mem(a)
{
	var id=0;
	var data=$('form').serialize();
	$.ajax({
		type: "GET",
		url: "new_voucher/memberclosed/index.php",
		data: "id="+id, data,
		success: function(data) {
			if(data==1)
			{
			alert("FD CLOSED Will be Created");
				//new_voucher();
			}
			else
			{
			alert("FD CLOSED Not Will Not be Created");
				//new_voucher();
			}
			}
		});
}
</script>