
<?php
require("../../configuration.php");
$member_no=$_REQUEST['member_no'];
$loan_no=$_REQUEST['loan_no'];
$fdr_no=$_REQUEST['fdr_no'];
$date=$_REQUEST['date'];

$fdLoan_sql="SELECT * FROM `fd_loan_header` WHERE `member_no`='$member_no' and `loan_no`='$loan_no' and `against_fdr_no` in('$fdr_no')";
$fdLoan_row=mysql_query($fdLoan_sql);
$fdLoan_check=mysql_num_rows($fdLoan_row);




if($fdLoan_check==0)
{
	echo 0;
}
else
{
echo 1;
}
?>