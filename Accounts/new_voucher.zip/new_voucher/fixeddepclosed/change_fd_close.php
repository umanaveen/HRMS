<?php  
require('../../configuration.php');


$date=$_REQUEST['date'];
	$fdr_no=$_REQUEST['fdr_no'];
	$cheque_no=$_REQUEST['cheque_no'];
	$flag_id='2';
	$fdr_sql="SELECT date,amount,interest_rate,interest_amount FROM fd_balance WHERE member_no='$member_no' and fdr_no='$fdr_no' and flag_id='$flag_id' ";
	$fdr_row=mysql_query($fdr_sql);
	$fdr_res=mysql_fetch_array($fdr_row);
	
	$fd_date=$fdr_res['date'];
	$fd_amount=$fdr_res['amount'];
	$fd_amount=round($fd_amount);
	$fd_interest_rate=$fdr_res['interest_rate'];
	$fd_interest_amount=$fdr_res['interest_amount'];
	
	$fd_interest_transaction_sql="SELECT SUM(interest_amount) as interest_amount FROM fd_interest_transaction
									WHERE
									fdr_no='$fdr_no' ";
		
	$fd_interest_transaction_row=mysql_query($fd_interest_transaction_sql);
	$fd_interest_transaction_res=mysql_fetch_array($fd_interest_transaction_row);
	
	$fd_interest_paid_amount=$fd_interest_transaction_res['interest_amount'];
	
	//$fd_interest_amount=$fd_amount*$fd_interest_rate/100;

	$fd_interest_amount=$fd_interest_amount-$fd_interest_paid_amount;
	
	$fd_interest_amount=round($fd_interest_amount);
	$fd_maturity_amount=$fd_amount+$fd_interest_amount;
?>
		<table class="table table-bordered table-striped" border="1">
		<thead>
<?PHP
if($ledger_code1!='Z001')  // its member closed
{	
	?>
<tr>
	<td colspan="3"><center>RECEIPTS</center></td>
	<td colspan="3"><center>PAYMENTS</center></td>
</tr>
<tr>
	<td>Head of Account</td>
	<td colspan="2">Amount</td>
	<td>Head of Account</td>
	<td colspan="2">Amount</td>
</tr>
<tr>
	<td></td>
	<td>Rs.</td>
	<td>P.</td>
	<td></td>
	<td>Rs.</td>
	<td>P.</td>
</tr>
<?PHP
}
else
{
	?>
<tr>
	<td colspan=6><center>RECEIPTS</center></td>
</tr>
<tr>
	
	<td colspan=4>Head of Account</td>
	<td colspan=2>Amount</td>
</tr>
<tr>
	<td colspan=4></td>
	<td>Rs.</td>
	<td>P.</td>
</tr>
<?PHP
}
?>
</thead>
		<tbody>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td>Fixed Deposit</td>
			<td align="right"><?php echo $fd_amount;?><input type="hidden" name="fd_amount" id="fd_amount" value="<?php echo $fd_amount;?>" /></td>
			<td></td>
		</tr>
		
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td>Interest paid on FD</td>
			<td align="right"><?php echo $fd_interest_amount;?><input type="hidden" name="fd_interest_amount" id="fd_interest_amount" value="<?php echo $fd_interest_amount;?>" /></td>
			<td></td>
		</tr>
		
		<tr>
			<td>Cheque No: &nbsp; <?php echo $cheque_no;?></td>
			<td align="right"><?php echo $fd_maturity_amount;?><input type="hidden" name="fd_maturity_amount" id="fd_maturity_amount" value="<?php echo $fd_maturity_amount;?>" /></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		</tbody>
		
		<tfoot>
	<tr>
		<td>Total</td>
		<td><?php echo $fd_maturity_amount;?></td>
		<td></td>
		<td>Total</td>
		<td><?php echo $fd_maturity_amount;?></td>
		<td></td>
	</tr>
		</tfoot>
		
		</table>