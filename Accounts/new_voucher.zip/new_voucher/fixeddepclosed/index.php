<?php

require('../../configuration.php');
require('../../user.php');

$user=$_SESSION['user'];
 	
 $memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
	
	require('../main_process.php');
$bank_codes=$_REQUEST['bank_code'];
$ledger_codes=$_REQUEST['ledger_code'];
$amounts=$_REQUEST['asl_amount'];
 
 $fddeposit=new voucher_process();	// CALL A CLASS NAME
 
	 $fddeposit->code=$v_code;
	
$fddeposit->voucher_category_code=$_REQUEST['voucher_category_code'];
$fddeposit->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
$fddeposit->date=date('Y-m-d'strtotime($_REQUEST['curdate']));
$fddeposit->member_no=$_REQUEST['member_no'];
$fddeposit->name=$_REQUEST['name'];
$fddeposit->branch_code=$_REQUEST['branch_code'];
$fddeposit->bank_code=$bank_codes;

$fddeposit->fd_amount=$_REQUEST['fd_amount'];
$fddeposit->fd_interest_amount=$_REQUEST['fd_interest_amount'];
$fddeposit->fd_maturity_amount=$_REQUEST['fd_maturity_amount'];  // 3 values get from change_fd_close.php

$fddeposit->amount=$amounts;

$fddeposit->cheque_no=$_REQUEST['cheque_no'];

$fddeposit->cheque_date=date('Y-m-d'strtotime($_REQUEST['cheque_date']));

	
	
	
    $bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_codes'");
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	$staffadjustmentcollection->ledger_code=$ledger_code;
	
	$fddeposit->ledger_code=$ledger_codes;
	$fddeposit->narration='FD CLOSED';
    $fddeposit->created_by=$user;
    $fddeposit->status=1;
	
	// $fddeposit->voucher_entry(); 
 
 $ledgers_code=array($ledger_codes,$ledger_code);
 $ledgers_amount=array($amounts,$amounts);
 $ledgers_type=array('credit','debit');
 
	// $fddeposit->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);
  
?>