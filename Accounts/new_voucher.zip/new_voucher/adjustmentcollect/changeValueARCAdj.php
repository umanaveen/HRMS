<?php
require("../../configuration.php");
require("../../user.php");

$member_no=$_REQUEST['member_no'];
$id=$_REQUEST['id'];
$amount=$_REQUEST['amount'];

if($id==1) //surety loan
{
	$member_balance_sql="SELECT surety_reg_balance,surety_principal
							FROM
								member_balance
							WHERE
								member_no='$member_no'";
								
	$member_balance_row=mysql_query($member_balance_sql);
	$member_balance_res=mysql_fetch_array($member_balance_row);
	
	$loan_reg_balance=$member_balance_res['surety_reg_balance'];
	
	$loan_principal=$member_balance_res['surety_principal'];
	
	$interest_rate_sql="SELECT interest_rate FROM loan_type WHERE code='LON-001' ";
	$interest_rate_row=mysql_query($interest_rate_sql);
	$interest_rate_res=mysql_fetch_array($interest_rate_row);
	
	$reg_interest_rate=$interest_rate_res['interest_rate'];

	$loan_interest=($loan_reg_balance*$reg_interest_rate/100)/12;
	$loan_interest=round($loan_interest);
}
else if($id==2) //festival loan
{
		$member_balance_sql="SELECT festival_reg_balance,festival_principal
							FROM
								member_balance
							WHERE
								member_no='$member_no'";
								
	$member_balance_row=mysql_query($member_balance_sql);
	$member_balance_res=mysql_fetch_array($member_balance_row);
	
	$loan_reg_balance=$member_balance_res['festival_reg_balance'];
	
	$loan_principal=$member_balance_res['festival_principal'];
	
	$interest_rate_sql="SELECT interest_rate FROM loan_type WHERE code='LON-002' ";
	$interest_rate_row=mysql_query($interest_rate_sql);
	$interest_rate_res=mysql_fetch_array($interest_rate_row);
	
	$reg_interest_rate=$interest_rate_res['interest_rate'];
	
	$loan_interest=($loan_reg_balance*$reg_interest_rate/100)/12;
	$loan_interest=round($loan_interest);
}
if($amount>$loan_interest)
{
	$paid_loan_interest=$loan_interest;
	$amount=$amount-$paid_loan_interest;
	$paid_loan_principal=$amount;
}
else
{
	$paid_loan_interest=$amount;
	$paid_loan_principal=0;
}

echo $loan_principal."=".$loan_interest."=".$paid_loan_principal."=".$paid_loan_interest."=".$loan_reg_balance;