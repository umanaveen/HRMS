<?php
require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];


$vou_category_id=$_REQUEST['vou_cat_code'];
 ?>
 
 <h4>Adjustment Collection</h4>
 <form type="POST">
<input type="hidden" name="vou_cat" id="vou_cat" value="<?php echo $vou_category_id;?>">
<table class="table table-bordered">

<td><input type="button" name="submit" onclick="adjust()"  value="Save" class="btn btn-primary btn-sm" /></td>
</tr>
</table>
</form>

<script>
function adjust()
{
	var data=$('form').serialize();
	$.get('new_voucher/adjust/index.php',data);
	
	/* $.ajax({
		type: "POST",
		url: "/UCO/voucher/voucherView.php",

		success: function(data)
		{
		$('#voucher_home').html(data);
		}
		}); */
}
</script>