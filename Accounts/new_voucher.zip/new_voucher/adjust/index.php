<?php


echo $_REQUEST['vou_cat'];
	
	

?>