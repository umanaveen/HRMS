<?php 
require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];
$cur_date=date('d-m-Y');
$convert_cur_date=date('Y-m-d',strtotime($cur_date));

$vou_category_id=$_REQUEST['vou_cat_code'];
$vou_pur_id=$_REQUEST['vouc_pur_id'];

// Get the vocuher code in voucher purpose table

$vouch_pur=mysql_query("select code from voucher_purpose where id='$vou_pur_id' and voucher_category_code='$vou_category_id'"); // get the purpose code 
$voucher_pur_code_count=mysql_num_rows($vouch_pur);
$vouch_pur_code=mysql_fetch_array($vouch_pur);  	// Get the data
$voucher_purp_code=$vouch_pur_code['code'];   		// voucher purpose code 
if($voucher_pur_code_count>0)  						// Voucher count greater than 0 -- Success function
{
	if($voucher_purp_code=='PUR-001') 				// New member Creation of Adjustment receipt
	{    											// echo "New member";
		?>
		<div id="new_member">
		<form>
		<table class="table table-bordered table-hover" style="margin:1px;">
		<thead style="FONT-SIZE: 14px;font-family: none;"><center>ADJUSTMENT RECEIPT - NEW MEMBER </center>
		</thead>
			
				<input type="hidden" class="form-control" id="voucher_category_code" name="voucher_category_code" value="<?php echo $vou_category_id; ?>" readonly="true"/>
				<input type="hidden" class="form-control" id="voucher_purpose_code" name="voucher_purpose_code" value="<?php echo $voucher_purp_code; ?>" readonly="true"/>
			<tr>
			<td>Date</td>
				<td>
					<div class="input-group"><div class="input-group-addon"><i class="fa fa-calendar"></i></div>
					<div id="cur_datetimepicker" class="input-append date">
						<div class="input-group" style="width:100%;">
						<input type="text" class="add-on form-control" id="date" name="date" title="Date" value="<?php echo date("d-m-Y"); ?>" />

						</div>
					<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
					</div>
					</div>
				</td>
			</tr>
			<tr>
				<td>Member No</td>
				<td><input type="text" class="form-control" id="member_no" name="member_no" value="" onchange="checkMember(this.value)" maxlength="5" autocomplete="off"/></td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type="text" class="form-control" id="name" name="name" value="" readonly="true"/></td>
			</tr>
			<tr>
				<td>Branch</td>
				<td>
				<input type="hidden" class="form-control" id="branch_code" name="branch_code" value=""/>
				<input type="text" class="form-control" id="branch_name" name="branch_name" value="" readonly="true"/></td>
			</tr>
			<tr>
				<td>Amount</td>
				<td><input type="text" class="form-control" id="amount" name="amount" onchange="new_mem_check(this.id)" autocomplete="off"/></td>
			</tr>
			<tr>
			<td>Bank</td>
			<!-- Default Bank Selection -->
			<td>
			<select class="form-control select2" id="bank_code" name="bank_code">
			<option value="bank-002">CURRENT A/C WITH UCO BANK (SOWCARPET)</option>
				<?PHP
				$bank_sql="SELECT code,name FROM bank WHERE code<>'BANK-002' ";
				$bank_row=mysql_query($bank_sql);
				while($bank_res=mysql_fetch_array($bank_row))
				{
				?>
				<option value="<?php echo $bank_res['code'];?>"><?php echo $bank_res['name'];?></option>
				<?php
				}
				?>
			</select>
			</td>
			</tr> 
		</table>
		<div id="details_of_amount"></div> 
		</form>
		</div>
		<br>		
		<div style="margin-bottom: 1px;text-align:right;">
		<input type="button" id="create_btn" name="create_member" class="btn btn-primary" onclick="member_create()" value="Save"/>
		</div>
		<br>
		<br>
			<?php 
	}	
	}
	else
	{
		echo "Choose an valid code";
	}
	?>
<script>
$(function() {
	$('#cur_datetimepicker').datetimepicker({
	format: "dd-MM-yyyy"
	});
});
$(function() {
	$('#datetimepicker1').datetimepicker({
	format: "dd-MM-yyyy"
	});
});
</script>
<script>
// Get User entered amount details pass amount_report_page return to "details_of_amount" div
function new_mem_check()
{
				var member_no=$('#member_no').val();
				var voucher_purpose_code=$('#voucher_purpose_code').val();
				var amount=$('#amount').val();
				var vou_entry_date='<?php echo $convert_cur_date; ?>';
			//	alert(vou_entry_date);
					
					if(member_no!="" && amount!="")
					{
						$.ajax({
								type: "GET",
								url: "/UCO/new_voucher/newmember/amount_report_page.php",
								data: "voucher_purpose_code="+voucher_purpose_code+"&member_no="+member_no+"&amount="+amount,
								
								success: function(data) {
									$('#details_of_amount').html(data);
								}
							});
					}
					else
					{
						alert("Please fill the Member No and Amount")
					}
}
function checkMember(v)
	{
	$.get('/UCO/new_voucher/checkMember.php?member_no='+v,function(data) { 
		var splitData=data.split("=");
		var mob=splitData[3];
		var dem_check=splitData[4];
		var mem_name=splitData[0];
		
			if(mem_name == '')   // If Member not exists....,,,,
			{
				alert("Invalid Member No....");
				$('#member_no').val(" ");
			}
			if(dem_check != 0)
			{
				alert('Member Demand is not closed / do only loan closed');
			}
			if(mob == "")
			{
				alert('Please Fix Mobile No');
			}
			else
			{
				$('#name').val(splitData[0]);
				$('#branch_code').val(splitData[1]);
				$('#branch_name').val(splitData[2]);	
			}
		});
		
	}
</script>
<script>
	/* it should allow only number in text box*/
	$("#member_no").bind('keypress', function (evt){
	 evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	{
		return false;
	}
return true;									
});	
/* check whether member number is valid or not */
</script>
<script>
	/* it should allow only number in text box*/
	$("#amount").bind('keypress', function (evt){
	 evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	{
		return false;
	}
return true;										
});	
/* check whether member number is valid or not */
</script>
<script>

function member_create()
{
	
	var member_no=$('#member_no').val();
	var amount=$('#amount').val();
	var bank_code=$('#bank_code').val();
	var cheque_no=$('#cheque_no').val();
	var date=$('#date').val();
	var data=$('form').serialize();
	var id=1;
	
	var cur_date="<?php echo $cur_date; ?>";
	var fieldss = cur_date.split('-');
	var day1=fieldss[0];
	var month1=fieldss[1];
	var year1=fieldss[2];
	
	
	var fields = date.split('-');
	var day=fields[0];
	var month=fields[1];
	var year=fields[2];
	
	$('#new_member').html('<br><div style="text-align: center;"><img src="/UCO/images/loader/loader.gif"></div>');
	 
	if ( (month <= month1) && (year <= year1))   // Check date Not greater than current dates
	{  
		if(member_no!='' && amount!='' && amount>0)
		{
			$.ajax({
					type:'GET',
					data:'id='+id, data,
					url:'new_voucher/newmember/index.php',
					success: function(data)
					{
						alert('New voucher be Created..!!');
						new_voucher();
					}				
					
				});
		}
		else
			{
				alert("Please Enter a Valid Amount Or Member No..");
			}
	}
	else
	{
		alert("Please Choose Date less than Current Date....");
	}
}
</script>