<?php
require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user']; 

	$bank_code=$_REQUEST['bank_code'];
	$amount=$_REQUEST['amount'];
	
	$memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
	require('../main_process.php');
	
	$mem_obj=new voucher_process();	

	$mem_obj->code=$v_code;
	$mem_obj->date=date("Y-m-d",strtotime($_REQUEST['date']));
	
	$mem_obj->voucher_category_code=$_REQUEST['voucher_category_code'];
	$mem_obj->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
		
	$mem_obj->member_no=$_REQUEST['member_no'];
	$mem_obj->reference=$_REQUEST['member_no'];
	
	
	$mem_obj->name=$_REQUEST['name'];
	$mem_obj->branch_code=$_REQUEST['branch_code'];
	$mem_obj->amount=$amount;
	
	$bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_code'");
	//$bank_row=$bank_sql['ledger_code'];
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	$mem_obj->ledger_code=$ledger_code;

	$mem_obj->bank_code=$bank_code;
	$mem_obj->cheque_no=$_REQUEST['cheque_no'];
	$mem_obj->cheque_date=date("Y-m-d",strtotime($_REQUEST['cheque_date']));
	$mem_obj->description=$_REQUEST['description'];

	$mem_obj->narration='OPN BAL'; 
	$mem_obj->status=1; 
	$mem_obj->created_by=$user_id; 

	$mem_obj->voucher_entry(); 

	$ledgers_code=array('H001','D001','E003','A003',$ledger_code);
	
	$ledgers_amount=array($_REQUEST['entrance_fees'],$_REQUEST['share_capital'],$_REQUEST['srf'],
							$_REQUEST['thrift_deposit'],$amount);
	
	$ledgers_type=array('credit','credit','credit','credit','debit');

	$mem_obj->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type);    
 ?>