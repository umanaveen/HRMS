<?php
	require('../../configuration.php');
	require('../../user.php');
	$user_id=$_SESSION['user'];

	$member_no=$_REQUEST['member_no'];
	$voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
	$amount=$_REQUEST['amount'];
	//$vou_entry_date=$_REQUEST['date'];
	
// Purpose code pur-001 Start here
	if($voucher_purpose_code=='PUR-001')
	{
		$ab_member=mysql_fetch_array(mysql_query("select employee_class from member where member_no='$member_no'"));   // Get the Employee class EX: A or B Class
		$employee_class=$ab_member['employee_class'];

		$ledger_amt=mysql_query("select * from ledger_fixed_amount where class_type='$employee_class' and flag_id=2");   // Get the Amount of entrance fees and some other things
		while($ledger_row=mysql_fetch_array($ledger_amt))
		{
			if($ledger_row['ledger_code']=="H001")
			{
				$entrance_fees=$ledger_row['amount'];
			}
			else if(($ledger_row['ledger_code']=="D001")||(($ledger_row['ledger_code']=="D002")))
			{
				$share_capital=$ledger_row['amount'];
			}
			else if($ledger_row['ledger_code']=="E003")
			{
				$srf=$ledger_row['amount'];
			}
			else if(($ledger_row['ledger_code']=="A003"))
			{
				$thrift=$ledger_row['amount'];
			}
			
		}
		$entrance_fees;
		$share_capital;
		$srf;
		$total=($entrance_fees+$share_capital+$srf);
				
		if($employee_class=="class b")
		{
			$share_capital=$amount;
			//$thrift=0;
		}
		else
		{
			$thrift=$amount-($entrance_fees+$share_capital+$srf);
		}
									
	// Amount greater than 1000 

	if($amount>=$total)
		{ 
		?>
	<table class="table table-bordered table-striped" border="1">
		<thead>
			<tr style="font-weight:600;">
				<td>Head of Account</td>
				<td>Rs.</td>
				<td>P.</td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Entrance Fees</td>
				<td align="right"><?php echo $entrance_fees;?>
				<input type="hidden" id="entrance_fees" name="entrance_fees" value="<?php echo $entrance_fees;?>" />
				</td>
				<td align="right">00</td>
			</tr>
			<tr>
				<td>Share Capital</td>
				<td align="right"><?php echo $share_capital;?>
				<input type="hidden" id="share_capital" name="share_capital" value="<?php echo $share_capital;?>" />
				</td>
				<td align="right">00</td>
			</tr>
			<tr>
				<td>Thrift Deposit</td>
			<td align="right"><?php echo $thrift;?>
			<input type="hidden" id="thrift_deposit" name="thrift_deposit" value="<?php echo $thrift;?>" />
			</td>
				<td align="right">00</td>
			</tr>
			<tr>
				<td>S.R.F</td>
			<td align="right"><?php echo $srf;?>
			<input type="hidden" id="srf" name="srf" value="<?php echo $srf;?>" />
			</td>
				<td align="right">00</td>
			</tr>
		</tbody>
		<tfoot>
			<tr>
				<td style="font-weight:600;">Total</td>
				<td align="right"><?php echo $amount;?></td>
				<td align="right">00</td>
			</tr>
		</tfoot>
	</table>
		<?PHP
		}  // If End here
			else
		{
		?>
			Please Change the amount its lessthan equal joining to joining amount 
		<?PHP	
		} 	 // Else End here
	} 
// Purpose code pur-001 End here
	?>