<?PHP 
   require("../../configuration.php");
   
   
	$date=$_REQUEST['vou_entry_date'];	
	$vou_date=date('Y-m-d',strtotime($date));
	 
	 $date3=strtotime($date).'<br>';
	
	$member_no=$_REQUEST['member_no'];
	$amount=$_REQUEST['amount'];
	$loan_no=$_REQUEST['loan_no'];
	
	$sum_loan_int=mysql_fetch_array(mysql_query("SELECT sum(interest_amount) as interest_amount FROM fd_loan_details WHERE loan_no='$loan_no' and flag_id=3 order by id desc "));
	
	if($sum_loan_int)
	{
	$fd_loan_interest_amount=$sum_loan_int['interest_amount'];
	}
	else
	{
	$fd_loan_interest_amount=0;
	}
	
	
	//int calculations
	$fdr_sql="SELECT * FROM fd_loan_details WHERE loan_no='$loan_no' and member_no='$member_no' 
	and flag_id='2'";	
	$fdr_row=mysql_query($fdr_sql);
	$fdr_res=mysql_fetch_array($fdr_row);
	
	$fd_eligible_amount=$fdr_res['elligible_amount'];
	
	$fd_loan_date=$fdr_res['date'];	
	$fd_loan_date=strtotime($fd_loan_date);
	
	
	
	$fd_loan_amount=$fdr_res['amount'];
	$fd_loan_amount=round($fd_loan_amount);
	
	 $intrest_rate=$fdr_res['interest_rate'];
	
	//$diff=date_diff($date,$date2);
//2 start fdr loan interest calculate
			 
	$datediff = $date3 - $fd_loan_date;
	$days=floor($datediff/(60 * 60 * 24));
	$fd_final_loan_int=($fd_loan_amount*($intrest_rate/100)/365);
	$fd_final_loan_int=round($fd_final_loan_int*$days);
			
	$fd_loan_int=$fd_final_loan_int+$fd_loan_interest_amount;
	

	if($fdr_res['flag_id']==2)
	{
	?>
	<input type="hidden" id="fd_loan_date" name="fd_loan_date" value="<?PHP echo $fd_loan_date;?>">
	<input type="hidden" id="fd_interest_rate" name="fd_interest_rate" value="<?PHP echo $intrest_rate;?>">
	<input type="hidden" id="fd_eligible_amount" name="fd_eligible_amount" value="<?PHP echo $fd_eligible_amount;?>">
	<input type="hidden" id="fd_loan_one_int_amount" name="fd_loan_one_int_amount" value="<?PHP echo $fd_final_loan_int;?>">
	<table class="table table-striped">
	<thead>
	<tr>
	<td>Loan Amount</td>
	<td>
	<input style="text-align:right" type="text" name="fd_loan_amount" id="fd_loan_amount" value="<?PHP echo $fd_loan_amount; ?>" class="form-control" readonly />
	</td>
	</tr>
	<tr>
	<td>Int Amount</td>
	<td>
	<input style="text-align:right" type="text" name="fd_loan_int_amt" id="fd_loan_int_amt" value="<?PHP echo $fd_loan_int; ?>" class="form-control" readonly />
	</td>
	</tr>
	<tr>
	<td>Principal</td>
	<td>
	<input style="text-align:right" type="text" name="principal" id="principal" value="" class="form-control"  autocomplete="off"/>
	</td>
	</tr>
	<tr>
	<td>Interest</td>
	<td>
	<input style="text-align:right" type="text" name="interest" id="interest" value="" class="form-control" autocomplete="off"/>
	</td>
	</tr>
	</tbody>
	<tfoot>
	<tr>
	<td>
	</td>
		<td style="float:right;margin-right:50px;"><input type="button" name="submit" onclick="fdloan()"  value="Save" class="btn btn-primary btn-md" /></td>
	</tr>
	<br>
	</tfoot>
	</table>			

	<?PHP
	}
//closed fd loan transaction	>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
	
	/* if($row1['flag_id']==2)
	{
		?>
		<input type="hidden" id="fd_loan_date" name="fd_loan_date" value="<?PHP echo $fd_loan_date;?>">
		<input type="hidden" id="fd_interest_rate" name="fd_interest_rate" value="<?PHP echo $fd_interest_rate;?>">
		<input type="hidden" id="fd_eligible_amount" name="fd_eligible_amount" value="<?PHP echo $fd_eligible_amount;?>">
		<input type="hidden" id="fd_loan_one_int_amount" name="fd_loan_one_int_amount" value="<?PHP echo $fd_loan_one_int_amount;?>">
		<table class="table table-striped">
				<thead>
					<tr>
						<th colspan="2"></th>
					</tr>
				</thead>
				<tbody>
					<tr>
								<td>Loan Amount</td>
								<td>
								<input type="text" name="fd_loan_amount" id="fd_loan_amount" value="<?PHP echo $fd_loan_amount; ?>" class="form-control" readonly />
								</td>
							</tr>
					<tr>
								<td>Principal</td>
								<td>
								<input type="text" name="principal" id="principal" value="<?PHP echo $amount; ?>" class="form-control" readonly />
								</td>
							</tr>
							<tr>
								<td>Total</td>
								<td>
								<input type="text" name="total" id="total" value="<?PHP echo $amount; ?>" class="form-control" readonly />
								</td>
							</tr>
							
							<tr>
								<td>One Day Interest</td>
								<td>
								<input type="text" name="fd_loan_one_int_amount" id="fd_loan_one_int_amount" value="<?PHP echo $fd_loan_one_int_amount; ?>" class="form-control" readonly />
								</td>
							</tr>
				</tbody>
				<tfoot>
					<tr>
						<th colspan="2"></th>
					</tr>
				</tfoot>
				</table>
		<?PHP
		//echo $loan_no."-".$loan_balance."-".$loan_interest."-".$loan_reg_balance."-".$loan_reg_interest."-".$loan_od_balance."-".$loan_od_interest."-".$previous_loan_od_interest."-".$scr;
	} 
	*/
	else
	{
		?>
		<script> alert(" Do Not Close FD Loan");
		//window.location.href = "../UCO/voucher/voucherView.php";
		</script>
		<?PHP
		}
	?>
	