<?php

require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];

$memsql=mysql_query("SELECT concat('VOU-',id+1) as v_code FROM voucher order by id desc limit 0,1");
	$check=mysql_num_rows($memsql);	
	if($check>0)
	{
		$mem_res=mysql_fetch_array($memsql);
		$v_code=$mem_res['v_code'];
	}
	else
	{
		$v_code='VOU-001';
	}
	
	require('../main_process.php');

	$fdloan=new voucher_process();


	echo $fdloan->voucher_category_code=$_REQUEST['vou_cat']; 
	echo $fdloan->voucher_purpose_code=$_REQUEST['voucher_purpose_code'];
	$fdloan->code=$v_code;
	$fdloan->date=date("Y-m-d",strtotime($_REQUEST['fd_date']));
	$fdloan->member_no=$_REQUEST['member_no'];
	$fdloan->reference_no=$_REQUEST['loan_no'];
	$fdloan->reference=$_REQUEST['loan_no'];
	$fdloan->name=$_REQUEST['name'];
	$fdloan->branch_code=$_REQUEST['branch_code'];
	$fdloan->amount=$_REQUEST['amount'];
	$fdloan->bank_code=$_REQUEST['bank_code'];;
		$bank_codes=$_REQUEST['bank_code'];

	$bank_sql=mysql_query("SELECT ledger_code FROM bank WHERE code='$bank_codes'");
	$bank_res=mysql_fetch_array($bank_sql);
	$ledger_code=$bank_res['ledger_code'];
	$fdloan->ledger_code=$ledger_code;

    $fdloan->narration='FD LOAN';	
    $fdloan->description='Loan Amount will be paid';	
    $fdloan->created_by=$user_id;	


		$fdloan->voucher_entry();


	$fdloan->fd_loan_date=$_REQUEST['fd_loan_date'];
	$fdloan->fd_interest_rate=$_REQUEST['fd_interest_rate'];
	$fdloan->fd_eligible_amount=$_REQUEST['fd_eligible_amount'];
	$fdloan->fd_loan_one_int_amount=$_REQUEST['fd_loan_one_int_amount'];
	$fdloan->fd_loan_amount=$_REQUEST['fd_loan_amount'];
	$fdloan->fd_loan_int_amt=$_REQUEST['fd_loan_int_amt'];
	$fdloan->principal=$_REQUEST['principal'];
	$fdloan->interest=$_REQUEST['interest'];

	$ledgers_code=array('G003','F007',$ledger_code);
	$ledgers_amount=array($_REQUEST['principal'],$_REQUEST['interest'],$_REQUEST['amount']);
	$ledgers_type=array('credit','credit','debit');

	$fdloan->voucher_details($ledgers_code,$ledgers_amount,$ledgers_type); 

?>