<?php
require('../../configuration.php');
require('../../user.php');
$user_id=$_SESSION['user'];

$vou_category_id=$_REQUEST['vou_cat_code'];
$vou_pur_id=$_REQUEST['vouc_pur_id'];

$vouch_pur=mysql_query("select code from voucher_purpose where id='$vou_pur_id' and voucher_category_code='$vou_category_id'"); // get the purpose code 
$voucher_pur_code_count=mysql_num_rows($vouch_pur);
$vouch_pur_code=mysql_fetch_array($vouch_pur);  	// Get the data
$voucher_purp_code=$vouch_pur_code['code'];   		// voucher purpose code 
if($voucher_pur_code_count>0)  						// Voucher count greater than 0 -- Success function
{
	if($voucher_purp_code=='PUR-010') 				// New member Creation of Adjustment receipt
	{
	?>
<h4><center>FD LOAN</center></h4>
 <form type="POST" id="fd_loan">
<div> 
	<input type="hidden" name="vou_cat" id="vou_cat" value="<?php echo $vou_category_id;?>">
	<table class="table table-bordered">
	<input type="hidden" class="form-control" id="voucher_purpose_code" name="voucher_purpose_code" value="<?php echo $voucher_purp_code; ?>" readonly="TRUE">
	<tr>
	<td>Date</td>
	<td>
	<div class="input-group"><div class="input-group-addon"><i class="fa fa-calendar"></i></div>
	<div id="fd_loan_datetimepicker" class="input-append date">
	<div class="input-group" style="width:100%;">
	<input type="text" class="add-on form-control" id="fd_date" name="fd_date" title=" Date" value="<?php echo date("d-m-Y"); ?>" />
	</div>
	<i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
	</div>
	</div>
	</td>
	</tr>
	<tr>
	<td>Member No</td>
	<td><input type="text" class="form-control" id="member_no" name="member_no" value="" onchange="checkMember(this.value)" maxlength="5" autocomplete="off"/></td>
	</tr>
	<tr>
	<td>Name</td>
	<td><input type="text" class="form-control" id="name" name="name" value="" readonly="true"/></td>
	</tr>
	<tr>
	<td>Branch</td>
	<td>
	<input type="hidden" class="form-control" id="branch_code" name="branch_code" value=""/>
	<input type="text" class="form-control" id="branch_name" name="branch_name" value="" readonly="true"/></td>
	</tr>
	<div id="branch_wise">
	</div>
	<tr>
	<td>Amount</td>
	<td><input type="text" class="form-control" id="amount" name="amount" onchange="check_amount(this.value)" value="" autocomplete="off"/></td>
	</tr>
	<tr>
	<td>Bank</td>
	<!-- Default Bank Selection -->
	<td><select class="form-control select2" id="bank_code" name="bank_code">
	<option value="bank-002">CURRENT A/C WITH UCO BANK (SOWCARPET)</option>
	<?PHP
	$bank_sql="SELECT code,name FROM bank WHERE code<>'BANK-002' ";
	$bank_row=mysql_query($bank_sql);
	while($bank_res=mysql_fetch_array($bank_row))
	{
	?>
	<option value="<?php echo $bank_res['code'];?>"><?php echo $bank_res['name'];?></option>
	<?php
	}
	?>
	</select>
	</td>
	</tr>			  
	
		<tr>
		<td width="50%">Loan No</td>
		<td>
		<?PHP
		$query=mysql_query("select loan_no from fd_loan_details where flag_id='2' order by loan_no asc");
		?>
		<select name="loan_no" id="loan_no" class="form-control" onchange="loan(this.value)">
		<option value="0">--LOAN NO LIST--</option>
		<?php
		while($row=mysql_fetch_array($query))
		{
		?>
		<option value="<?PHP echo $row['loan_no'];?>"><?PHP echo $row['loan_no'];?></option>
		<?php 
		} 
		?>
		</select>
		</td>
		</tr>
</table>
</div>
<div id="loan_balance">
</div>
</form>
<script>

$(function() {
	$('#fd_loan_datetimepicker').datetimepicker({
	format: "dd-MM-yyyy"
	});
}); 
function loan(v)
{
var member_no=$('#member_no').val();				
var amount=$('#amount').val();
var vou_entry_date=$('#fd_date').val();
if(member_no!='' && amount!='')
{
$.ajax({
type: 'get',
url: '/UCO/new_voucher/fdloan/fd_loan_balance.php',
data: 'member_no='+member_no+'&loan_no='+v+'&amount='+amount+'&vou_entry_date='+vou_entry_date,

success: function(data)
{
//alert(data);
$('#loan_balance').html(data);
}
});
}
else
{
	alert("Please Choose Member No and Amount");
}
}
</script>
<script>
function fdloan()
{
	var id=1;
	var member_no=$('#member_no').val();				
	var amount=$('#amount').val();
	
	var principal=$('#principal').val();
	var interest=$('#interest').val();

	var tot_amount=+principal + +interest;
	//alert(tot_amount);
	var vou_entry_date=$('#fd_date').val();
	var data=$('form').serialize();
		
	if(amount!=tot_amount)
	{
		alert("LEDGER AMOUNT AND LOAN AMOUNT SHOULD NOT BE EQUAL...!!!!");
	}
	else
	{
		$('#fd_loan').html('<br><div style="text-align: center;"><img src="/UCO/images/loader/loader.gif"></div>');
		if(member_no!='' && amount!='')
		{
			$.ajax({
				type: 'GET',
				data: 'id='+id, data,
				url: 'new_voucher/fdloan/index.php',
				success: function(data)
				{
					new_voucher();
				}
			});
		}
		else
		{
			alert("CHOOSE AN MEMBER NUMBER OR AMOUNT SHOULD BE GREATER HT");
		}
		
	}
}
</script>

<?php
	}
}
?>